const express = require('express')
const app=express();
const cookieParser= require('cookie-parser')
const boardRouter = require('./routes/board.js');
const customerRouter = require('./routes/customer.js');
const todoRouter = require('./routes/todo.js');
const fileRouter = require('./routes/file.js');
const cors =require("cors");
const morgan = require('morgan');

const multer = require("multer");
const upload =multer({dest:'d:/upload/'})

const port=3000;


app.use(morgan(':date :method :url :status'));
app.use(cors());
app.use(cookieParser())
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const requestTime = function (req, res, next) {
    req.requestTime = Date.now()
    
    next()
  }
  
  app.use(requestTime)


app.use("/board",boardRouter);
app.use("/customer",customerRouter);
app.use("/todo",todoRouter);
app.use("/file",fileRouter);
 
//method
app.get(     "/",    (req,res)=>{
    res.cookie("cookieName", "cookieValue");
    console.log('Cookies: ',req.cookies)
    res.send("hello world!~");
});

app.get("/post",(req,res)=>{
    res.send("post world");
});

// app.get(/a/,(req,res)=>{
//     res.send("regular wxpression~~");
// });

app.get(/^insert/,(req,res)=>{
    res.send("insert로 시작하는");
});

const ex0 = function(req,res,next){
    console.log('첫번째 콜백');
    next();
}

const ex1 = function(req,res,next){
    console.log('두번째 콜백');
    next();
}

const ex2 = function(req,res,next){
    res.send('세번째 콜백');
    
}

app.get("/examples",[ex0,ex1,ex2]);

app.listen(port,()=>{
    console.log(`http://127.0.0.1:${port} 서버 실행`)
})

