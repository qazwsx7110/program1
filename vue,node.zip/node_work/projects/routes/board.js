const express = require('express');
const router =express.Router()

const query = require("../mysql");

// router.get("/",(req,res)=>{
//     console.log(new Date(req.requestTime).toLocaleDateString());
    
// })

router.get("/page=:page",(req,res)=>{
    query("boardList",(parseInt(req.params.page)-1)*10)
    .then(result=>res.send(result))
    
})



router.get("/:no",(req,res)=>{
    console.log(req.body);
    query("boardGet",req.params.no)
    .then(result=>res.send(result))
    
})

router.post("/",(req,res)=>{
    console.log(req.body);
    query("boardInsert",req.body)
    .then(result=>res.send(result))
    
})

// router.post("/",upload.single("XXXX"),(req,res)=>{
//     let data = {...req.body};
//     //첨부파일이 아니면
//     if(null 아니면){
//         data.filename=req.file.XXXXXX
//         data.uploadfilename=________
//     }
//     query("boardInsert",data)
//     .then(result=>res.send(result))
// })

router.put("/:no",(req,res)=>{
    console.log(req.body);
    query("boardUpdate",[req.body,req.params.no])
    .then(result=>res.send(result))
    
})

router.delete("/:no",(req,res)=>{
    console.log(req.body);
    query("boardDelete",req.params.no)
    .then(result=>res.send(result))
    
})

module.exports = router;