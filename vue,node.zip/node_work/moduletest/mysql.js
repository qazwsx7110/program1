const mysql = require("mysql2"); 

// mysql 접속 정보
const conn = { host: "127.0.0.1", 
 port: "3306", 
 user: "hr", 
 password: "hr", 
 database: "test" };
// DB 커넥션 생성
let connection = mysql.createConnection(conn); 

sql="SELECT * FROM customers";

connection.query(sql, function(err, results, fields) {
    if (err) { 
     console.log(err);
    }
     // 3. 결과 처리
    console.log(results);
    });
    // DB 접속 종료
   
connection.end(); 