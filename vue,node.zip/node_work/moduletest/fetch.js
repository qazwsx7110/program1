const axios = require('axios');
let url ='http://localhost:3000/posts';
//fetch post
let data={"id":"5","title":"test56"}

axiosput();

function axiosput(){
    axios.put(url,data)
    .then(json=>console.log(json))
    .catch(err=>console.log(err));
  }

//fetchput();

function fetchput(){
    fetch(url+"/5",{
      method:"put",
      headers:{ "content-type":"application/json;charser=UTF-8"},
      body:JSON.stringify(data)
    }).then(response=>response.json())
    .then(json=>console.log(json))
    .catch(err=>console.log(err));
  }



//fetchpost(); // 호이스팅 (끌올)
//axiospost();

function axiospost(){
  axios.post(url,data)
  .then(json=>console.log(json))
}


function fetchpost(){
  fetch(url,{
    method:"post",
    headers:{ "content-type":"application/json;charser=UTF-8"},
    body:JSON.stringify(data)
  }).then(response=>response.json())
  .then(json=>console.log(json))
  .catch(err=>console.log(err));
}


//fetch get
function fetchget(){
fetch(url)
.then(response=>response.json())
.then(json=>console.log(json))
}

//axios get
axios.get(url)
.then(json=>console.log(json.data))