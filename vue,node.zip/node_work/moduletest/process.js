const process=require('process');
const os = require('os');
//import process from 'process';

process.on('beforeExit',(code)=>{

    console.log('2.종료 직전',code)
})

process.on('exit',(code)=>{

    console.log('3.종료될 때',code)
})

//process.exit();
console.log('1.첫번째 메세지');
//console.log(process.env);
console.log('hostname',os.hostname());
console.log('type',os.type());
console.log('hostname',os.homedir());

console.log(process.env.USERNAME);