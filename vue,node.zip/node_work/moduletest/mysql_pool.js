const mysql = require("mysql2"); 

// mysql 접속 정보
const conn = { 
    connectionLimit:10,
    host: "127.0.0.1", 
 port: "3306", 
 user: "hr", 
 password: "hr", 
 database: "test" };

 //statment,prepareStatment
 const pool=mysql.createPool(conn);
let name='홍길동'
let email = 'd@d.d'
let phone= '222-3333'

 const sql="insert into customers set ? ";
 const params = {name:'김기자',email:'q@q.q',phone:'444-4444',address:'대구'}

 pool.query(sql,params,function(err,result){

console.log(result);
 })