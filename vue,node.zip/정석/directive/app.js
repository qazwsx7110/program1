import headers from './header.js';
import databinding from './dataBinding.js';
import fors from './for.js';
import ifs from './if.js';
import events from './event.js';
import posts from './posts.js';

const { createApp } = Vue
const template = /*html*/` <div>
                              <headers/>
                              <posts/>                           
                           </div>`
//vue 인스턴스 생성
const component = {
  template ,
  name : "모듈연습",
  //components : {headers, databinding, fors, ifs ,events, posts},
  data(){ return { name:'홍길동', msg:'안녕하세요~~~~'  } },
  methods : {
     funca(){},
  },
  created(){    },
  mounted(){    },
  computed : { 
     fullname(){},
  }
}
createApp(component).mount("#app");