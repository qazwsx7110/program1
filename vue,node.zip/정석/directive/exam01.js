//exam01.js => ModelComponent

let template =/*html*/`
<div>
    <h2>자기소개</h2>
    <label> 이름 : <input type="text"></label><br>
    <label> 좋아하는 색은 : <br>
        <input type="radio" value="red"> 빨강 <br>
        <input type="radio" value="green"> 녹색 <br>
        <input type="radio" value="blue"> 파랑색 <br>
        <input type="radio" value="yellow"> 노란색 <br>
        <input type="radio" value="gray"> 회색 <br>
    </label>
    <select v-model="mySelectColor" >
        <option value="">좋아하는색</option>
        <option value="red"> 빨강 </option>
        <option value="green"> 녹색 </option>
        <option value="blue"> 파랑색 </option>
        <option value="yellow"> 노란색 </option>
        <option value="gray"> 회색 </option>
    </select>
    <textarea>    
    <p> 내 이름은 XXXX 이고 <br>
        좋아하는 색은 XXXX 입니다. </p>
</div>
`;

export default{
    template,
    data(){
        return {   }
    }
}