const template = `
  <div>
   <h1> user profile  </h1>
  </div> 
`
export default {
  template
}