const template = `
  <div>
   <h1> user posts  </h1>
  </div> 
`
export default {
  template
}