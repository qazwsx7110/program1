const template = `
  <div>
   <h1> about 페이지  </h1>
  </div> 
`
export default {
  template
}