<template>
  <div>blog</div>
  <div>{{id}}</div>
  <div>{{title}}</div>
</template>
<script>
  export default {
    props : {
      id : Number,
      title : String
    },
  data(){ return {}; },
  created(){},
  methods: {}
  }
</script>
<style></style>