<template>
  <div>
    <h1>사원수정</h1>

  </div>
</template>
<script>
  export default {
  data(){ return {}; },
  created() {},
  methods: {}
  }
</script>
<style></style>