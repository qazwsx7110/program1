<template>
  <div>
    <h1>사원등록</h1>
    <div>employee_id<input v-model="emp.employee_id"></div>
    <div>first_name<input v-model="emp.first_name"></div>
    <div>last_name<input v-model="emp.last_name"></div>
    <div>email<input v-model="emp.email"></div>
    <div>hire_date<input v-model="emp.hire_date"></div>
    <div>job_id: <select v-model="emp.job_id">
      <option v-for="___" :value="__" v-text="__"></option>
    </select></div>
    <button @click="addHandler">등록</button>
  </div>
</template>
<script>
  
  export default {
  data(){ return {
    emp : {  employee_id : 100, first_name : '', last_name:'' , email : '', hire_date :'', job_id : ''  },
    jobs :[]
  }; },
  created() {

  },
  methods: {
    async addHandler(){
      await axios.post("", emp)
      //목록으로 이동($router.push("___"))
    }
  }
 }
</script>
<style></style>