let moduleB;
export const moduleA = 'hello'
export default moduleB = function(){
    console.log("moduleB")
}
export class moduleC{
    constructor() {
        console.log('module C');
    }
}
//export {moduleA, moduleB, moduleC}