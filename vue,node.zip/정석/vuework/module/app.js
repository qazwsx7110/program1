// import * as mymodule from './module.js'
// console.log(mymodule.moduleA)
// mymodule.moduleB();
// let mc = new mymodule.moduleC();
import defaultmodule from './module.js'
defaultmodule();
