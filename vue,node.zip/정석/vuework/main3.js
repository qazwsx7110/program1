const app = Vue.createApp({
    data() {
        return {
            product: 'Socks',
            image: './assets/images/socks_green.jpg',
            // solution
            url: 'https://www.vuemastery.com/',
            // solution
            inStock: true
        }
    },
    methods: {
          f1(){},
          f2(){} 
      }
})
