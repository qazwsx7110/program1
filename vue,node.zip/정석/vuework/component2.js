//component.js

let component = {
  name: "", // 컴포넌트 이름

  template: ``, // View
  components: {}, // 자식 컴포넌트들 추가

  data() {}, // Data : CRUD
  computed: {}, // Data 계산 : Read
  watch: {}, // Data 감시

  setup() {}, // 컴포지션 API
  created() {}, // 컴포넌트가 생성되면 실행(훅)
  mounted() {}, // 템플릿이 랜더링되면 실행(훅)

  methods: {}, // Code : 기능정의
};
