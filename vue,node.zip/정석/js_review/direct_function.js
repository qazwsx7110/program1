/* 즉시 실행 함수 */
(function print(msg){
  console.log(msg);
})('실행');



