let moduleB;
export const moduleA = 'hello~~~'
export default function moduleC(){
    console.log("moduleC 호출")
}
//export {moduleA, moduleB}