//app.js
// => Root Component

//import { createApp, ref } from 'https://unpkg.com/vue@3/dist/vue.esm-browser.js';
import RawComponent from './raw.js';
import InputComponent from './input.js';
import ModelComponent from './exam01.js';
import ListComponent from './list.js';
import ForComponent from './exam02.js';
import IfComponent from './if.js';
import EventComponent from './event.js';
import WatchComponent from './watch.js';
//import CountComponent from './count.vue';

const { createApp } = Vue
//const { createApp } = 'vue';

const template =/*template*/`
<div>
    <!-- 자식 컴포넌트 추가 -->
    <button @click="count++">{{ count }}</button>
    <ListComponent/>
</div>
`;

// createApp({
//     //template,
//     components : {
//         RawComponent, 
//         InputComponent,
//         ModelComponent,
//         ListComponent,
//         ForComponent,
//         IfComponent,
//         EventComponent,
//         WatchComponent,
//         CountComponent
//     },
//     data() {
//         return {
//           count: 0
//         }
//       }
// })
// .mount('#app');


const app = createApp({
    template,
    data() {
      return {
        count: 0
      }
    }
  })
  app.component('ListComponent', ListComponent)
  app.mount('#app')