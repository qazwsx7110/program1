import router from "./router.js";
import HeaderComponent from "./component/header.js";
import FooterComponent from "./component/footer.js";

const { createApp } = Vue;

let template = /*html*/ `
<div>
  <h1>Hello App!</h1>
  <p>
    <strong>현재 라우트 경로:</strong> {{ $route.fullPath }}
  </p>
  <nav>
    <RouterLink to="http://127.0.0.1:5500/%EC%98%88%EC%A0%9C%ED%8C%8C%EC%9D%BC/cdn_3/beforeweek/router/index.html">인덱스으로 가기</RouterLink> | 
    <RouterLink to="/home2">홈으로 가기</RouterLink>  | 
    <RouterLink to="/about">소개로 가기</RouterLink>  | 
    <RouterLink to="/user">사용자로 가기</RouterLink>  | 
    <RouterLink to="/param/kim">파라미너</RouterLink>   |
    <RouterLink to="/query?name=kim">쿼리</RouterLink>
    </nav>
    <main>
    <RouterView />
    </main>
    </div>
    `;
// <RouterLink :to="{path : '/param', params:{username:'hong'}">파라미터</RouterLink>  |
createApp({
  template,
  components: {
    HeaderComponent,
    FooterComponent,
  },
  created() {
    this.$router.push("/");
  },
})
  .use(router)
  .mount("#app");
