//import { createMemoryHistory, createRouter } from 'vue-router'
const { createRouter, createWebHistory } = VueRouter;
import IndexView from "./view/IndexView.js";
import HomeView from "./view/HomeView.js";
import AboutView from "./view/AboutView.js";
import UserView from "./view/UserView.js";

import UserHomeView from "./view/UserHomeView.js";
import UserProfileView from "./view/UserProfileView.js";
import ParamView from "./view/ParamView.js";
import QueryView from "./view/QueryView.js";
import NotFound from "./view/NotFound.js";

const routes = [
  { path: "/", component: IndexView },
  { path: "/home2", redirect: "/home" },
  { path: "/home", component: HomeView },
  { path: "/about", component: AboutView },
  { path: "/param/:username", component: ParamView },
  {
    path: "/user",
    component: UserView,
    props: true,
    // children: [
    //   // UserHome will be rendered inside User's <router-view>
    //   // when /users/:username is matched
    //   { path: "", component: UserHomeView },

    //   // UserProfile will be rendered inside User's <router-view>
    //   // when /users/:username/profile is matched
    //   { path: "profile", component: UserProfileView },
    // ],
  },
  { path: "/query", component: QueryView },
  { path: "/:pathMatch(.*)*", name: "NotFound", component: NotFound },
];

const router = createRouter({
  //history: createMemoryHistory(),
  history: createWebHistory(),
  linkActiveClass: "border-indigo-500",
  routes,
});

export default router;
