const template = `
<footer>
  <div>copyright @@@</div>
</footer>`;

export default {
  template,
};
