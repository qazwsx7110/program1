const template = `
  <div>query </div>
  <div>{{this.$route.query.name}}</div>
`;

export default {
  template,
};
