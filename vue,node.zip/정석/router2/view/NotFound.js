const template = `
  <div>query </div>
`;

export default {
  template,
};
