const template = `
  <div>home </div>
  <a href="#"  @click.prevent="gotoUser('park')">사용자프로파일</a>
`;

export default {
  template,
  methods: {
    gotoUser(username) {
      this.$router.push({
        path: `/user`,
        params: { username: username },
        query: { username: username },
      }); //
    },
  },
};
