const template = `
  <div class="user">
  <nav>
    <RouterLink to="./">사용자홈</RouterLink>  | 
    <RouterLink to="./profile">사용자프로파일</RouterLink>
  </nav>  
    <h2>User {{ this.$route.params.username }}</h2>
    <router-view></router-view>
  </div>
`;

export default {
  template,
};
