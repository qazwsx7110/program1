const template = `
  <div>about </div>
`;

export default {
  template,
};
