const template = `
  <div>user home </div>
`;

export default {
  template,
};
