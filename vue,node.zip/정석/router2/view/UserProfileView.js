const template = `
  <div>user profile </div>
`;

export default {
  template,
};
