const template = `
  <div>index </div>
`;

export default {
  template,
};
