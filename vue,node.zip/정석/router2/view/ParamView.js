const template = `
  <div>파라미터 {{username}} </div>
`;

export default {
  template,
  //props: { username: String },
  data() {
    return {
      username: "",
    };
  },
  created() {
    this.username = this.$route.params.username;
  },
};
