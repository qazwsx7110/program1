<template>
  <div class="home">
    <PageTitle title="컴포넌트 사용 예제" menuno="10">test</PageTitle>
    <MenuBar :menu="['신발','상의','하의']"></MenuBar>
    <HelloWorld :user="user"/>
    <!-- <HelloWorld :user/> -->
     <ChildComponent ref="child_component"/>

     <hr>
      <ChildComponent4 @send-message="sendMesssage"></ChildComponent4>
       
      <SlotMadalLayout>
        <template v-slot:header>팝업타이틀</template>
        <template v-slot:default>팝업컨테츠</template>
        <template v-slot:footer>닫기</template>
      </SlotMadalLayout>
      

     <hr>
     <ProvideinjectChild></ProvideinjectChild>
     <FooterTitle>카피라이트</FooterTitle>
  <PagingComponent v-bind="page" @go-page="goPage"/>
  count:{{ count }}
  <button type="button" @click="increment">store count 증가</button>
    </div>


</template>

<script>
// @ is an alias to /src
import "bootstrap"
import "bootstrap/dist/css/bootstrap.min.css"
import HelloWorld from '@/components/HelloWorld.vue'
import PageTitle from '@/components/pageTitle.vue'
import MenuBar from '@/components/MenuBar.vue'
import ChildComponent from '@/components/ChildComponent.vue'
import ChildComponent4 from '@/components/ChildComponent4.vue'
import SlotMadalLayout from '@/components/SlotMadalLayout.vue'
import ProvideinjectChild from '@/components/ProvideinjectChild.vue'
import PagingComponent from '@/components/PagingComponent.vue'

export default {
  name: 'HomeView',
  components: {
    HelloWorld,PageTitle,MenuBar,ChildComponent,ChildComponent4,SlotMadalLayout,ProvideinjectChild, PagingComponent
  },
  data(){
    return{user:{username:'choi',msg:'hi'},page:{}
  }},
  provide(){
    return {itemlength:4}
  },
computed:{
  count(){
    return this.$store.state.count;
  }
}
  ,

  methods:{
    increment(){
             this.$store.commit('increment');
    },

    goPage(page){
          console.log('parent event',page);
    },

    sendMesssage(msg){
      console.log(msg);
    },
    pageCalc(currentPage, total, pageSize = 10, pageUnit = 10) {
      let firstPage = 1;
      let lastPage =
        Math.floor(total / pageUnit) + (total % pageUnit == 0 ? 0 : 1);
      let startIdx = Math.floor((currentPage - 1) / pageSize) * pageSize + 1;
      let endIdx = startIdx + pageSize - 1;
      if (endIdx > lastPage) {
        endIdx = lastPage;
      }
      
      return {currentPage, firstPage, lastPage, startIdx, endIdx };
    }
  },
  
  mounted(){
    //자식 컴포넌트 이벤트 발생
     
    this.$refs.child_component.childFunc();
    this.$refs.child_component.$refs.username.value='aaaa'
    this.$refs.child_component.$refs.username.focus();
  },
  created(){
    this.page=this.pageCalc(6,124,5,10);
  }

}
</script>
