const customerSql=require("./customerSql")

module.exports={
    ...customerSql

}