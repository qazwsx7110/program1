setTimeout(function(){
	console.log("step1");	
},1000);

setTimeout(function(){
	console.log("step2");	
},3000);

setTimeout(function(){
	console.log("step3");	
},2000);
