document.addEventListener("DOMContentLoaded",initForm);



function initForm(){
	svc.empList();
	fetch('../empJson.json')
	.then((result)=> result.json())
	.then((data)=>{
		data.forEach(emp=>{			
			let tr = makeRow(emp);
			document.querySelector('#elist').appendChild(tr);
		})			
	})	
	.catch(err=>console.log(err));	


    document.querySelector('#addBtn').addEventListener('click',addRow);
}

function makeRow(emp={}){
	let props =['emp','empName','email','salary'];
	
	let tr = document.createAttribute('tr');
		
	props.forEach(prop=>{
		let td=document.createElement('td');
		td.innerHTML=emp[prop];
		tr.appendChild(td);
	});
	let td = document.createAttribute('td');
		let btn = document.createAttribute('button');
		btn.innerHtml='삭제';
		btn.addEventListener('click',deleteRow);
  tr.appendChild(btn);
  tr.appendChild(td);
  		
	return tr;
}

function deleteRow(){
	let eno= this.parentElement.parentElement.dataset.no;
	let tr= this.parentElement.parentElement;
	
	fetch('../empsave.json?job=delete&empNo='+eno)
	.then(result=>result.json())
	.then(data=>{
		if(data.retCode=='OK'){
			tr.remove();
		}else if(data.retCode=='NG'){
			alert('처리 실패!');
		}
	})
	.catch(err=>console.log(err));	
	
}


function addRow(){
	const addHtp = new XMLHttpRequest();
	let ename=document.querySelector('#ename').value;
	let ephone=document.querySelector('#ephone').value;
	let ehire=document.querySelector('#edate').value;
	let esalary=document.querySelector('#esalary').value;
	let email=document.querySelector('#email').value;
	let param='job=add?name='+ename+'&phone='+ephone+'&salary='+esalary+'&hire='+ehire+'&email='+email;
	
	fetch('../empsave.json',{
		method:'post',
		headers:{'Content-Type':'application/x-www-form-urlencoded'},
		body:param
	})
	.then(result=>result.json())
	.then(data=>{
		if(result.retCode=='OK'){
			let tr = makeRow(result.retVal);
			document.querySelector('#elist').appendChild(tr);
		}
		
	})
	.catch(console.log);
	
 	addHtp.open('post','../empsave.json');
 	addHtp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    addHtp.send(param);
    addHtp.onload=function(){
		let result= JSON.parse(addHtp.responseText);
		console.log(result);
		if(result.retCode=='OK'){
			let tr = makeRow(result.retVal);
			document.querySelector('#elist').appendChild(tr);
		}
	}

}

function updateRow(){
	let oldTr=this.parentElement.parentElement;
	let empNo=this.parentElement.parentElement.dataset.no;
	let email=this.parentElement.parentElement.children[2].children[0].value;
	let salary=this.parentElement.parentElement.children[3].children[0].value;
	let param='job=edit?empNo='+empNo+'&phone='+ephone+'&salary='+esalary+'&hire='+ehire+'&email='+email;
	
	const editHtp=new XMLHttpRequest();
	editHtp.open('get','../empsave.json?job=edit&empNo'+empNo+'&salary'+salary+'&email'+email);
	editHtp.send();
	editHtp.onload=function(){
		let result= JSON.parse(editHtp.responseText);
		if(result.retCode='OK'){
			let newTr
		}
	}
	
}


function modifyRow(){
	let originMail= this.children[2].innerText;
	let originSalary= this.children[3].innerText;
	let oldTr=this;
	
	let newTr=this.cloneNode(true);
	newTr.querySelector('td:nth-of-type(3)').innerHTML='<input value="">'+originMail+'">';
	newTr.querySelector('td:nth-of-type(4)').innerHTML='<input value="5000">'+originSalry+'">';
	newTr.querySelector('button').innerText='수정';
	newTr.querySelector('button').addEventListener('click',updateRow);
	oldTr.parentElement.replaceChild(newTr,oldTr);
	
	
	console.log(newtr);
	oldTr.parentElement.replacechild(newTr,oldTr);
	
}
