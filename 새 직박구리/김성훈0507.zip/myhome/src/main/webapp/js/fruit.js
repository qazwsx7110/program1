console.log(document.querySelector('button'));
document.querySelector('#addBtn').addEventListener('click',function(){
	let text =document.querySelector('input').value;
	let price =document.querySelector('input:nth-of-type(2)').value;
	let li = document.createElement('li');
	
	li.innerText=text+'('+price+')';
	let btn = document.createElement('button');
	btn.innerText='삭제';
	li.appendChild(btn);
	btn.addEventListener('click',function(){
		console.log(this);
		this.parentElement.remove();
	})
	
	let ul = document.querySelector('ul');
	ul.appendChild(li);
});
