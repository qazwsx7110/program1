const showTitles = ['id','centerName','address','side','phoneNumber']
let url='https://api.odcloud.kr/api/15077586/v1/centers?page=1&perPage=284&serviceKey=MmddflL0dcWkfZ771b8PxLIGjXgPjEtt1GNQuBX%2BkamRgsienWW71vT1jXbQ0bqJT4XaTHNg9FJctHPsF9%2B3RA%3D%3D'

let totalData=[]

fetch(url)
.then(result=>result.json())
.then(data=>{
	console.log(data);
	totalData=data.data;
	//data.data.forEach(center=>{
	//	let tr = makeRow(center);
	//	document.querySelector('#list').appendChild(tr);
	//})
	showPaging(2);
	
	//pagingList();
})
.catch(console.log);

document.querySelectorAll('.pagination a').forEach(aTag=>{
	console.log(aTag);
	
	aTag.addEventListener('click',function(e){
		e.preventDefault();
		let page = this.innerText;
		console.log('fdsf');
		showPaging(page);
		
	})
	
})

let totalCnt=284;
function pagingList(page=1){
	let pagination= document.querySelector('.pagination');
	pagination.innerHTML='';
	let endPage,startPage;
	let prev,next;
	let realEnd =Math.ceil(totalCnt/10);
	endPage=Math.ceil(page/10)*10;
	startPage = endPage-9;
	endPage=endPage>realEnd?realEnd:endPage;
	next = endPage<realEnd?true:false;
	prev=startPage>1;
	
	
	//aTag 생성,이벤트 추가.
	if(prev)
	{
		let aTag=document.createElement('a');
		aTag.setAttribute('href','#');
		aTag.setAttribute('data-page',startPage-1);
		aTag.innerHTML='&laquo;';
		aTag.addEventListener('click',function(e){
			let page =  e.target.dateset.page;
			showPaging(page);
			
		})
		pagination.appendChild(aTag);
	}
	
	for(let n=startPage;n<=endPage;n++){
		let aTag = document.createElement('a');
		aTag.setAttribute('href','#');
		aTag.innerHTML=n;
		if(page==n){
			aTag.className='active';
		}
		aTag.addEventListener('click',function(e){
			let page =  e.target.innerHtml;
			console.log(page);
			showPaging(page);
			
		})
		pagination.appendChild(aTag);
	}
	if(next)
	{
		let aTag=document.createElement('a');
		aTag.setAttribute('href','#');
		aTag.setAttribute('data-page',endPage+1);
		aTag.innerHTML='&raquo;';
		aTag.addEventListener('click',function(e){
			let page =  e.target.innerHtml;
			showPaging(page);
			
		})
		pagination.appendChild(aTag);
	}
	
}

function showPaging(page){//0~9:1page,10~19:2page
	let startNo=(page-1)*10;
	let endNo=page*10;
	
	let fAry=totalData.filter((center,idx)=>{if(idx>=startNo&&idx<endNo){
		return true;
	}
	
	})
	document.querySelector('#list').innerHTML='';
	
	fAry.forEach(center=>{
		let tr = makeRow(center);
		document.querySelector('#list').appendChild(tr);
	})
	
	console.log(fAry);
	pagingList(page);
}


function makeRow(center={}){
		
	let tr = document.createElement('tr');
		tr.addEventListener('click',function(e){
			
			let enc= encodeURI(center.centerName);
			window.open('daum.html?x='+center.lat+'&y='+center.lng+'&lo='+enc);
		})
	showTitles.forEach(title=>{
		let td=document.createElement('td');
		let name = center[title];
		td.innerHTML=(name+'').replace('코로나19',' ');
		tr.appendChild(td);
	});
	
  		
	return tr;
}