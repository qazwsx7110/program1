

const svc={

    empList:function(successCall,errorCall){
	fetch('../empJson.json')
	.then(result=>result.json())
    .then(successCall)
    .catch(erroCall);
    },
    
    addEmp(param={},successCall,errorCall){
		fetch('../empsave.json',{
		method:'post',
		headers:{'Content-Type':'application/x-www-form-urlencoded'},
		body:'job=edit?empNo='+param.empNo+'&salary='+param.salary+'&email='+param.email		
	})
	.then(result=>result.json())
	.then(successCall)
	.catch(erroCall);
	},
	
    deleteEmp(){
		
		
    }
	
}


