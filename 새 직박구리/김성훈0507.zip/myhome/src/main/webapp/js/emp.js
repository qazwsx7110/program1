document.addEventListener("DOMContentLoaded",initForm);


function initForm(){
	
	const xhtp= new XMLHttpRequest();
	xhtp.open('get','../empJson.json');
	xhtp.send();
	xhtp.onload = function(){
		let data = JSON.parse(xhtp.responseText);
		
		console.log(data);
		
		data.forEach(emp=>{
			
			let tr = makeRow(emp);
			document.querySelector('#elist').appendChild(tr);
		})
	}
	
}

document.querySelector("#addBtn").addEventListener('click',addRow);

function addRow(){
	const addHtp = new XMLHttpRequest();
	let ename=document.querySelector('#ename').value;
	let ephone=document.querySelector('#ephone').value;
	let ehire=document.querySelector('#edate').value;
	let esalary=document.querySelector('#esalary').value;
	let email=document.querySelector('#email').value;
	
	let param='job=add?name='+ename+'&phone='+ephone+'&salary='+esalary+'&hire='+ehire+'&email='+email;
 	addHtp.open('post','../empsave.json');
 	addHtp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    addHtp.send(param);
    addHtp.onload=function(){
		let result= JSON.parse(addHtp.responseText);
		console.log(result);
		if(result.retCode=='OK'){
			//let tr = makeRow(result.retVal);
			//document.querySelector(#)
		}
	}

}


function makeRow(emp={}){
	let props =['emp','empName','email','salary'];
	
	let tr = document.createAttribute('tr');
		
	props.forEach(prop=>{
		let td=document.createElement('td');
		td.innerHTML=emp[prop];
		tr.appendChild(td);
	});
	let td = document.createAttribute('td');
		let btn = document.createAttribute('button');
		btn.innerHtml='삭제';
		btn.addEventListener('click',deleteRow);
  tr.appendChild(btn);
  tr.appendChild(td);
  		
	return tr;
}

function deleteRow(){
	const delNo=this.parentElemant.parentElement.children[0].innerText;
	let tr=this.parentElement.parentElement;
	console.log(delNo);
	const delHtp = new XMLHttpRequest();
	delHtp.open('get','../empsave.json?empNo='+delNo);
	delHtp.send();
	delHtp.onload=function(){
	let result =JSON.parse(delHtp.responseText);
	if(result.retCode=='OK'){
		tr.remove();
		
	}else if(result.retCode=='NG'){
		alert('처리중 에러발생');
		
	}else{
		alert('처리코드 확인하세요');
	}							
	}			
}

function modifyRow(){
	let originMail= this.children[2].innerText;
	let originSalary= this.children[3].innerText;
	let oldTr=this;
	
	let newTr=this.cloneNode(true);
	newTr.querySelector('td:nth-of-type(3)').innerHTML='<input value="">'+originMail+'">';
	newTr.querySelector('td:nth-of-type(4)').innerHTML='<input value="5000">'+originSalry+'">';
	newTr.querySelector('button').innerText='수정';
	newTr.querySelector('button').addEventListener('click',updateRow);
	oldTr.parentElement.replaceChild(newTr,oldTr);
	
	
	console.log(newtr);
	oldTr.parentElement.replacechild(newTr,oldTr);
	
}

function updateRow(){
	let oldTr=this.parentElement.parentElement;
	let empNo=this.parentElement.parentElement.dataset.no;
	let email=this.parentElement.parentElement.children[2].children[0].value;
	let salary=this.parentElement.parentElement.children[3].children[0].value;
	
	
	const editHtp=new XMLHttpRequest();
	editHtp.open('get','../empsave.json?job=edit&empNo'+empNo+'&salary'+salary+'&email'+email);
	editHtp.send();
	editHtp.onload=function(){
		let result= JSON.parse(editHtp.responseText);
		if(result.retCode='OK'){
			let newTr
		}
	}
	
}


