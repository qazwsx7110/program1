package com.yedam.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yedam.dao.EmpDAO;

/**
 * Servlet implementation class EmpDatatableServ
 */
@WebServlet("/EmpDatatableServ")//datatable
public class EmpDatatableServ extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setContentType("text/json;charset=utf-8");
		//
		EmpDAO edao = new EmpDAO();
		List<Map<String,Object>> list = edao.empList();
		
		String json="{\"";
		json+="data\":[";
		for(int i = 0;i<list.size();i++) {
			Map<String,Object> map = list.get(i);
			json+="[\""+map.get("사원번호")
			+"\",\""+ map.get("사원명")
			+"\",\""+ map.get("연락처")
			+"\",\""+ map.get("이메일")
			+"\"]";
			if((i+1)!=list.size()){
				json+=",";
			}
		}
		
		json+="]";
		
		response.getWriter().print(json);
		
	}
}
