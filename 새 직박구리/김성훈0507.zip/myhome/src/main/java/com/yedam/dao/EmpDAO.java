package com.yedam.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.yedam.common.DAO;
import com.yedam.vo.EmpVo;

public class EmpDAO extends DAO {

	public List<Map<String,Object>> empList(){
		 List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
	     conn();
	     try {
			psmt=conn.prepareStatement("select * from emp");
			rs=psmt.executeQuery();
			while(rs.next()) {
				Map<String,Object> map=new HashMap<>();
				map.put("사원번호", rs.getString("emp_no"));
				map.put("사원명", rs.getString("emp_name"));
				map.put("연락처", rs.getString("emp_phone"));
				map.put("이메일", rs.getString("email"));
				
				list.add(map);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			disCon();
		}
	     
	     
	     
		return list;
	     
	     
	}
	
	public List<EmpVo>  selectList(){
		conn();
		ResultSet rs;
		String list="select * from emp";
	
		List<EmpVo> EmpList =new ArrayList();
		
	     try {
	    	
			psmt=conn.prepareStatement(list);				    	
			rs= psmt.executeQuery();
	    	
			while(rs.next()) {
				EmpVo evo = new EmpVo();
				evo.setEmpNo(rs.getInt("emp_no"));
				evo.setEmpName(rs.getString("emp_name"));
				evo.setEmpPhone(rs.getString("emp_phone"));
				evo.setHireDate(rs.getString("hire_date"));
				evo.setEmail(rs.getString("email"));
				evo.setSalary(rs.getInt("salary"));
				
				EmpList.add(evo);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			disCon();
		}
		
		return EmpList;
	}
	
	public EmpVo selectEmp(int no) {
		conn();
		ResultSet rs;
		String list="select * from emp where emp_no =?";
		
	     try {
	    	
			psmt=conn.prepareStatement(list);				    	
			psmt.setInt(1, no);
			rs= psmt.executeQuery();
	    	
			if(rs.next()) {
				EmpVo evo = new EmpVo();
				evo.setEmpNo(rs.getInt("emp_no"));
				evo.setEmpName(rs.getString("emp_name"));
				evo.setEmpPhone(rs.getString("emp_phone"));
				evo.setHireDate(rs.getString("hire_date"));
				evo.setEmail(rs.getString("email"));
				evo.setSalary(rs.getInt("salary"));
				
				return evo;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			disCon();
		}
		return null;
	}
	
	public boolean insertEmp(EmpVo evo) {
		
		conn();
		String insert="insert into emp (emp_no,emp_name,emp_phone,email,hire_date,salary) ";
		insert+="values (emp_seq.nextval,?,?,?,?,?)";
	     try {
	    	
			psmt=conn.prepareStatement(insert);				    	
	    	
			psmt.setString(1, evo.getEmpName());		 
			 psmt.setString(2, evo.getEmpPhone());
			 psmt.setString(3, evo.getEmail());
			 psmt.setString(4, evo.getHireDate());
			 psmt.setInt(5, evo.getSalary());
	    	
			psmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			disCon();
		}
		
		return false;
	}
	
	public boolean updateEmp(EmpVo evo) {
		
		conn();
		
		String update="update emp set emp_name=?,emp_phone=?,email=?,hire_date=?,salary=? where emp_no=?";
		
	     try {
	    	
			psmt=conn.prepareStatement(update);				    	
	    	
			psmt.setString(1, evo.getEmpName());		 
			 psmt.setString(2, evo.getEmpPhone());
			 psmt.setString(3, evo.getEmail());
			 psmt.setString(4, evo.getHireDate());
			 psmt.setInt(5, evo.getSalary());
			 psmt.setInt(6, evo.getEmpNo());
		    	
			psmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			disCon();
		}
		
		
		
		return false;
	}
	
	
	public boolean deleteEmp(int empNo) {
		
conn();
		
		String delete="delete emp where emp_no=?";
		
	     try {
	    	
			psmt=conn.prepareStatement(delete);				    	
	    	
			
			 psmt.setInt(1, empNo);
		    	
			psmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			disCon();
		}
		
		
		
		return false;
	}
	
	//5월 7일
	public Map<String,Integer> getCntperDept(){
		conn();
		String sql = "select d.department_name "+"   ,count(1) as cnt "+
				"from hr.employees e "+
				"join hr.departments d "+
				"on e.department_id = d.department_id "+
				"group by d.department_name";
		Map<String,Integer> map = new HashMap<String,Integer>();
		try {
			
			psmt=conn.prepareStatement(sql);
			rs=psmt.executeQuery();
			while(rs.next()) {
				System.out.println(rs.getString("department_name")+rs.getInt("cnt"));
				map.put(rs.getString("department_name"),rs.getInt("cnt"));
				
			}
			
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return map;
	}
	
	
     //datatable.html에 불러오기
	public List<EmpVo>  getDataTable(){
		conn();
		ResultSet rs;
		String list="select * from emp";
	
		List<EmpVo> EmpList =new ArrayList();
		
	     try {
	    	
			psmt=conn.prepareStatement(list);				    	
			rs= psmt.executeQuery();
	    	
			while(rs.next()) {
				EmpVo evo = new EmpVo();
				evo.setEmpNo(rs.getInt("emp_no"));
				evo.setEmpName(rs.getString("emp_name"));
				evo.setEmpPhone(rs.getString("emp_phone"));
				evo.setHireDate(rs.getString("hire_date"));
				evo.setEmail(rs.getString("email"));
				evo.setSalary(rs.getInt("salary"));
				
				EmpList.add(evo);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			disCon();
		}
		
		return EmpList;
	}
	
	//jsp.employees 테이블의 사원번호값찾아 삭제
	
	
}


