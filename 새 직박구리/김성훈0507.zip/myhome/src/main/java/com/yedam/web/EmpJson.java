package com.yedam.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.yedam.dao.EmpDAO;
import com.yedam.vo.EmpVo;

@WebServlet("/empsave.json")
public class EmpJson extends HttpServlet  {
	@Override
	protected void service(HttpServletRequest request,HttpServletResponse response) throws IOException{
 
           String job= request.getParameter("job");
           EmpDAO edao=new EmpDAO();
           EmpVo evo =new EmpVo();
           Map<String,Object> map= new HashMap<>();
           Gson gson =new GsonBuilder().create();
 
          if(job.equals("add")) {
        	  String a= request.getParameter("name");
        	  String b= request.getParameter("phone");
        	  String c= request.getParameter("salary");
        	  String d= request.getParameter("hire");
        	  String e= request.getParameter("email");
        	  
        	  evo.setEmail(e);
        	  evo.setEmpName(a);
        	  evo.setEmpPhone(b);
        	  evo.setHireDate(d);
        	  evo.setSalary(Integer.parseInt(c));
        	  
        	  
        	  if(edao.insertEmp(evo)) {
        	  map.put("retCode","OK");
        	  map.put("retVal","OK");
        	  
        	  response.getWriter().print(gson.toJson(map));
          }
        	  else {
        		  map.put("retCode", "NG");
        		  map.put("retVal",null);
        		  response.getWriter().print(gson.toJson(map));
        	  }
        	  }
          else if(job.equals("edit")) {
        	  
        	  
        	  
	          //evo.setEmpNo(Integer.parseInt(eno));
	          //evo.setSalary(Integer.parseInt(c));
	          //evo.setEmail(e);
	          
	          if(edao.updateEmp(evo)) {
	        	  evo=edao.selectEmp(evo.getEmpNo());
	        	  map.put("retCode","OK");
	        	  map.put("retVal",evo);
	          }else {
	        	  map.put("retCode","NG");
	        	  map.put("retVal",null);
	        	  
	          }
	 
           }
         
	 
	}
	
}
