package com.yedam.vo;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter
public class EmpVo {
	private int empNo;
	private String empName;
	private String empPhone;
	private String email;	
	
	private String hireDate;
	private int salary;
	
//	public int getEmpNo() {
//		return empNo;
//	}
//	public void setEmpNo(int empNo) {
//		this.empNo = empNo;
//	}
//	public String getEmpName() {
//		return empName;
//	}
//	public void setEmpName(String empName) {
//		this.empName = empName;
//	}
//	public String getEmpPhone() {
//		return empPhone;
//	}
//	public void setEmpPhone(String empPhone) {
//		this.empPhone = empPhone;
//	}
//	public String getEmail() {
//		return email;
//	}
//	public void setEmail(String email) {
//		this.email = email;
//	}
//	public String getHireDate() {
//		return hireDate;
//	}
//	public void setHireDate(String hireDate) {
//		this.hireDate = hireDate;
//	}
//	public int getSalary() {
//		return salary;
//	}
//	public void setSalary(int salary) {
//		this.salary = salary;
//	}
	
	public String toString() {
		return this.empNo+this.empName+this.empPhone+this.email+this.hireDate+this.salary;
	}
}
