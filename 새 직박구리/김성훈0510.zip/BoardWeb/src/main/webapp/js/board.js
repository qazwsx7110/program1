document.querySelector('#modBtn').addEventListener('click',function(){
	
	document.forms.myfrm.action="modBoardForm.do";
	document.forms.myfrm.submit();
})

document.querySelector('.btn-danger').addEventListener('click',function(){
	document.forms.myfrm.action="";	
})