package com.yedam.common;

import lombok.ToString;
import lombok.Getter;

@Getter
@ToString
public class pageDTO {

	private int page;
	private int starPage,endPage;
	private boolean prev,next;
	
	public pageDTO(int page,int totalCnt) {
		
		this.page=page;
		int realEnd = (int)Math.ceil(totalCnt/5.0);
		
		this.endPage=(int)Math.ceil(page/5.0)*5;
		this.starPage=this.endPage-4;
		this.endPage= this.endPage>realEnd ? realEnd: this.endPage;
		
		
		this.prev=this.starPage>1;
		this.next=this.endPage<realEnd ? true:false; 
	}
}
