package com.yedam.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.yedam.common.Control;
import com.yedam.service.BoardService;
import com.yedam.service.BoardServiceIml;
import com.yedam.vo.BoardVO;
import com.yedam.vo.MemberVO;


public class AddBoardControl implements Control {

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 
		String savePath = req.getServletContext().getRealPath("images");
		int maxSize= 5*1024*1024;
		
		
		
		MultipartRequest mr=new MultipartRequest(req,savePath,maxSize,"utf-8",new DefaultFileRenamePolicy());
		
		String title = mr.getParameter("title");
		String content = mr.getParameter("content");
		String writer = mr.getParameter("writer");
		String img = mr.getParameter("writer");

		
		if (svc.addBoard(vo)) {
		System.out.println("등록성공.");
		// 페이지이동 :목록페이지.
		resp.sendRedirect("main.do");

	} else {
		System.out.println("등록실패.");
		resp.sendRedirect("addForm.do");

	}
		
//	    BoardService svc = new BoardServiceIml();
//		
//		MemberVO mvo = svc.checkMember(writer);
//		if(mvo==null) {
//			req.setAttribute("message", "권한이 없습니다.");
//			req.getRequestDispatcher("WEB-INF/board/addboard.jsp").forward(req, resp);
//			return;
//		}
//		
//		BoardVO vo = new BoardVO();
//		vo.setTitle(title);
//		vo.setContent(content);
//		vo.setWriter(writer);
//
//		if (svc.addBoard(vo)) {
//			System.out.println("등록성공.");
//			// 페이지이동 :목록페이지.
//			resp.sendRedirect("main.do");
//
//		} else {
//			System.out.println("등록실패.");
//			resp.sendRedirect("addForm.do");
//
//		}
//		
		
		
	
	}

}
