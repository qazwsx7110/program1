package com.yedam.vo;

import lombok.Data;

@Data
public class MemberVO {

	private String userId;
	private String userName;
	private String userPw;
	private String userResp;
	
	
}
