package com.yedam.common;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.yedam.mapper.BoardMapper;
import com.yedam.service.BoardService;
import com.yedam.service.BoardServiceIml;
import com.yedam.vo.BoardVO;

public class BoardTest {

	public static void main(String[] args) {
		
	//test	
		SqlSession session=DataSource.getInstance().openSession(true);;		
		
		BoardMapper mapper = session.getMapper(BoardMapper.class);
		
		List<BoardVO> list0 = mapper.boardList();
		System.out.println(list0.size());
		for(BoardVO board : list0) {
			System.out.println(board.toString());
		}
		//test	
		
		BoardService svc = new BoardServiceIml();
		
		//add
		BoardVO vo =new BoardVO();
		vo.setTitle("fdsaf");
		vo.setContent("fdsaf");
		vo.setWriter("fdsa");
		
		
		if(svc.addBoard(vo)) {
			System.out.println("등록");
		}else {
			System.out.println("실패");
		}
		
		//add
		//select
		BoardVO vo2 = svc.getBoard(1);
		System.out.println("호출"+vo2.getContent());
		
		//select
//		List<BoardVO> list = svc.boardList();
//		for(BoardVO board : list) {
//			System.out.println(board.toString());
//			System.out.println("fdasfad");
			
			
		//paging 
			svc.boardList(3).forEach(board->System.out.println(board));
		
	}

}
