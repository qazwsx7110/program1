package com.yedam.service;

import java.util.List;

import com.yedam.vo.BoardVO;
import com.yedam.vo.MemberVO;

public interface BoardService {

	public List<BoardVO> boardList(int page);
	
	public boolean addBoard(BoardVO board);
	BoardVO getBoard(int boardNO);
	
	int addViewCnt(int boardNo);
	
	//modify
	
	public boolean deleteBoard(int boardNO);
	
	MemberVO login(String id,String pw);
	MemberVO checkMember(String id);
	
	public int getTotal();
}
