package com.yedam.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yedam.common.Control;
import com.yedam.service.BoardService;
import com.yedam.service.BoardServiceIml;
import com.yedam.vo.BoardVO;

public class BoardinfoControl implements Control {

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String page=req.getParameter("page");
		
		//Spring bro=
		
		
		 BoardService svc = new BoardServiceIml();
		 //BoardVO vo = svc.getBoard(Integer.parseInt(bro));
		 //svc.
		 
			
		 String path = "WEB-INF/board/board.jsp";
			req.getRequestDispatcher(path).forward(req, resp);
	}

}
