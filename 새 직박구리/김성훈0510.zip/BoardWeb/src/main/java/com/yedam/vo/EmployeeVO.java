package com.yedam.vo;

import lombok.Data;

@Data
public class EmployeeVO {

	private int employeeId;
	public String firstName;
	public String lastName;
	private String email;
	private String jobId;

}
