package com.yedam.common;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.yedam.mapper.EmpMapper;

public class DataTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SqlSessionFactory factory=DataSource.getInstance();
		SqlSession session = factory.openSession(true);
		
		EmpMapper mapper = session.getMapper(EmpMapper.class);
		int r = mapper.deleteEmp(99);
		System.out.println("fasdf");
	}

}
