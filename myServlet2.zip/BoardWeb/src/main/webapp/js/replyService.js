/**
 * replyService.js
 */
const svc = {
	// 댓글목록 => 페이지, 성공콜백, 실패콜백
	replyList() {

	},
	// 댓글등록 => 댓글정보, 성공콜백, 실패콜백
	addReply() {

	},
	// 댓글삭제 => 삭제할번호, 성공콜백, 실패콜백
	removeReply() {

	}
}