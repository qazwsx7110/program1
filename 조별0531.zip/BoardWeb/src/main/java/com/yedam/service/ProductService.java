package com.yedam.service;

import java.util.List;

import com.yedam.vo.BoardVO;
import com.yedam.vo.CimageVO;
import com.yedam.vo.OptionVO;
import com.yedam.vo.ProductVO;
import com.yedam.vo.TmemberVO;

public interface ProductService {
	boolean addCimages(CimageVO cimage);
	boolean addProduct(ProductVO product);
	boolean addOption(OptionVO option);
	boolean deleteOption(int productcode);
	
	boolean updateTimages(ProductVO producttimage);
	boolean updateTimages2(CimageVO cimage);
	
	String getTimages(int productcode);
	List<CimageVO> getCimages(int productcode);
	List<OptionVO> getOptions(int productcode);
	ProductVO getProduct(int productcode);
	CimageVO getCimage(int productcode,int cimageorder);
	
	boolean modifyProduct(ProductVO product);
}
