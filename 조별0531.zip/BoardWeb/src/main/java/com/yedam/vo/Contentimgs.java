package com.yedam.vo;

import lombok.Data;

@Data

public class Contentimgs {

	private int climag;
	private int productcode;
	private int productcode2;
    private String clmagename;
    private int clmagorder;
	
    
}
