package com.yedam.vo;

import lombok.Data;

@Data

public class CimageVO {
	private int cimageno;
	private int productcode;
	private String cimagename;
	private int cimageorder;
}
