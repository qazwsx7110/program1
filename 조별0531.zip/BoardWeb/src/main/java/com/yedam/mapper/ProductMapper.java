package com.yedam.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.yedam.vo.CimageVO;
import com.yedam.vo.OptionVO;
import com.yedam.vo.ProductVO;
import com.yedam.vo.ReplyVO;

public interface ProductMapper {

	int addProduct(ProductVO product);
	int addCimages(CimageVO cimage);
	int addOption(OptionVO option);
	int deleteOption(int productcode);
	ProductVO getProduct(int productcode);
	List<OptionVO> getOption(int productcode);
	List<CimageVO> getCimages(int productcode);
	CimageVO getCimage(@Param("productcode") int productcode, @Param("cimageorder") int cimageorder);
	int modifyProduct(ProductVO product);
	String getProductimg(int productcode);
	int updateTimage(ProductVO product);
	int updateTimage2(CimageVO cimage);
	
}
