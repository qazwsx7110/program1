package com.yedam.web;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.yedam.common.Control;
import com.yedam.service.BoardServiceImpl;
import com.yedam.service.ProductService;
import com.yedam.service.ProductServicelmpl;
import com.yedam.vo.CimageVO;
import com.yedam.vo.OptionVO;
import com.yedam.vo.ProductVO;

public class AddProductControl implements Control {
	
	
	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ProductService productservice = new ProductServicelmpl();
		
		File Folder = new File(req.getServletContext().getRealPath("images")+"/temp");
		//상품폴더 생성
		if (!Folder.exists()) {
			try{
				Folder.mkdir(); //폴더 생성합니다.
				System.out.println("폴더가 생성되었습니다.");
			} 
			catch(Exception e){
				e.getStackTrace();
			}        
			
		}else {
			System.out.println("이미 폴더가 생성되어 있습니다.");
		}		
		int maxSize = 5 * 1024 * 1024;
		
		String savePath = req.getServletContext().getRealPath("images")+"/temp";
		
		MultipartRequest mr = new MultipartRequest(req, savePath, maxSize, "utf-8"//
				, new DefaultFileRenamePolicy());
		
		System.out.println(mr.getParameter("pcode"));
		File renameFile = new File(req.getServletContext().getRealPath("images")+"/"+mr.getParameter("pcode"));
		
		Folder.renameTo(renameFile);
				
		//타이틀 폴더 생성
		
		File TitleFolder = new File(req.getServletContext().getRealPath("images")+"/"+mr.getParameter("pcode")+"/title");
		if (!TitleFolder.exists()) {
			try{
				TitleFolder.mkdir(); //폴더 생성합니다.
				System.out.println("타이틀폴더가 생성되었습니다.");
			} 
			catch(Exception e){
				e.getStackTrace();
			}        
			
		}else {
			System.out.println("이미 타이틀폴더가 생성되어 있습니다.");
		}		
		//
		String timagename="";		
		Iterator<String> fileNames=(Iterator<String>) mr.getFileNames();
			
		
		
		try {
			int tno=1;
			while(fileNames.hasNext()){
				
				String fileName = fileNames.next();	
				
				if(mr.getFile(fileName)!=null) {									
					
					String filename2 = mr.getFile(fileName).getName();
			        
					
					if(fileName.equals("title")) {
						
						CimageVO cimg = new CimageVO();
						cimg.setCimageno(500000);
						cimg.setProductcode(Integer.parseInt(mr.getParameter("pcode")));
						cimg.setCimagename(filename2);
						cimg.setCimageorder(0);
						
						productservice.addCimages(cimg);
						timagename+=filename2;
						//파일이동
						
						try {
							File file = FileUtils.getFile(renameFile+"/"+filename2);
							File fileToMove = FileUtils.getFile(TitleFolder+"/"+filename2);
							FileUtils.moveFile(file, fileToMove);
						} catch (IOException e) {
							e.printStackTrace();
						}																		
						//						
					}
					
					else {
				System.out.print("번호:"+fileName+" 파일명 "+filename2+" ");
				
				
				CimageVO cimg = new CimageVO();
				cimg.setCimageno(tno);
				cimg.setProductcode(Integer.parseInt(mr.getParameter("pcode")));
				cimg.setCimagename(filename2);
				cimg.setCimageorder(Integer.parseInt(fileName.trim()));
				
				productservice.addCimages(cimg);
				
				tno++;
					}
				//글등록
				
				}
			}
			//상품등록
			
			ProductVO product = new ProductVO(); 
			product.setProductcode(Integer.parseInt(mr.getParameter("pcode")));
			product.setProductname(mr.getParameter("pname"));
			product.setPrice(Integer.parseInt(mr.getParameter("price")));
			product.setProductimg(timagename);
			
			productservice.addProduct(product);
			
			//
			//옵션등록						
			String[] options=mr.getParameterValues("option");
			for(int i = 0; i< options.length; i++){ 
				System.out.println(options[i]);
			    } 
			String[] oprices=mr.getParameterValues("oprice");
			for(int i = 0; i< oprices.length; i++){ 
				System.out.println(oprices[i]);
			    }
			
			
			OptionVO option= new OptionVO();
			for(int i = 0; i< options.length; i++) {
				option.setOptioncode(i);
				option.setOptionname(options[i]);
				option.setOptionprice(Integer.parseInt(oprices[i]));
				option.setProductcode(Integer.parseInt(mr.getParameter("pcode")));
				productservice.addOption(option);
				
			}						
			//
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	
	
	
}
