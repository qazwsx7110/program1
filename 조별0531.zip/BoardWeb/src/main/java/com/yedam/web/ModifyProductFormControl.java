package com.yedam.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yedam.common.Control;
import com.yedam.service.MemberService;
import com.yedam.service.MemberServiceImpl;
import com.yedam.service.ProductService;
import com.yedam.service.ProductServicelmpl;
import com.yedam.vo.CimageVO;
import com.yedam.vo.OptionVO;
import com.yedam.vo.ProductVO;


public class ModifyProductFormControl implements Control{

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("utf-8");
		
		ProductService ms= new ProductServicelmpl();
		
		List<CimageVO> cimagelist= ms.getCimages(500);
		req.setAttribute("cimagelist", cimagelist);
		
		//
		
		//
		ProductVO product = ms.getProduct(500);
		req.setAttribute("product", product);
		
		List<OptionVO> Option= ms.getOptions(500);
		req.setAttribute("options", Option);
		
		for(int i=0;i<cimagelist.size();i++) {
			System.out.println("배열"+i+"번 이름:"+cimagelist.get(i).getCimagename());
			System.out.println("배열"+i+"번 순서:"+cimagelist.get(i).getCimageorder());						
		}

		
		String path = "board/modifyProduct.tiles";
		req.getRequestDispatcher(path).forward(req, resp);
		
		
	}

}
