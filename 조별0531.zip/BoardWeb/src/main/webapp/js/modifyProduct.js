/**
 * 
 */
var cimageorder;
firstimage(500);
function firstimage(productcode) {
	
	fetch('firstimage.do?productcode='+productcode)
		.then(resolve => resolve.json())
		.then(result => {
			
		console.log(result)
		result.forEach(result=> {
				
			 const fileDiv = document.createElement('div');
	fileDiv.innerHTML =`	
	<div class="simage">    
	<input type="button" value="업" onClick="fn_up(this)"><input type="button" value="다운" onClick="fn_down(this)">                                      
              <img src="images/`+result.productcode+`/`+result.cimagename+`"  name="file" />                
              <input type="file" name="`+result.cimageorder+`" value="`+result.cimageorder+`" onchange="viewFile(this)";/>
              <input type="button" value="삭제" onClick="fn_remove(this)">
     </div>  
       
	`;		
	  document.querySelector('.file_list').appendChild(fileDiv);
	  cimageorder++;
	     cimageorder=result.cimageorder+1;
			})	
			
			
		})
		.catch(err => console.log(err))
}

function fn_addoption(){
	 const optionDiv = document.createElement('div');
	optionDiv.innerHTML =`
	
	<div class="option_input">                          
                            
              옵션이름<input type="text" name="option" ;/>가격<input type="text" name="oprice";/>
              <input type="button" value="삭제" onClick="fn_remove(this)">
     </div>     
	`;		
	  document.querySelector('.option_list').appendChild(optionDiv);
	 optioncnt++;
  }  
 
   function fn_remove(element){
	element.parentElement.remove();
  }  
  
  
   function readURL(input) {
 if (input.files && input.files[0]) {
  var reader = new FileReader();
  
  reader.onload = function (e) {
	console.log(input.parentElement.querySelector('img'));
   input.parentElement.querySelector('img').setAttribute('src', e.target.result);  
  }
  
  reader.readAsDataURL(input.files[0]);
  }
}

 function viewFile(e) {
	readURL(e);
	
	
 }
  function fn_addFile(){
	 const fileDiv = document.createElement('div');
	fileDiv.innerHTML =`	
	<div class="simage">    
	<input type="button" value="업" onClick="fn_up(this)"><input type="button" value="다운" onClick="fn_down(this)">                        
              <img name="file" />                
              <input type="file" name="`+cimageorder+`" value="`+cimageorder+`" onchange="viewFile(this)";/>
              <input type="button" value="삭제" onClick="fn_remove(this)">
     </div>  
     <script></script>   
	`;		
	  document.querySelector('.file_list').appendChild(fileDiv);
	  cimageorder++;
  } 
 
  function fn_change(element){
	console.log(element.parentElement.querySelector('input[name="changeimg"]'));
	element.parentElement.querySelector('input[name="changeimg"]').value='true'
	;
  }  
  
  function fn_up(element){
    
	//넘버변경
	const pname=element.parentElement.parentElement.previousSibling.querySelector('input[type=file]').getAttribute("name");
	const pvalue=element.parentElement.parentElement.previousSibling.querySelector('input[type=file]').getAttribute("value");
	const namep=element.parentElement.parentElement.querySelector('input[type=file]').getAttribute("name");
	const valuep=element.parentElement.parentElement.querySelector('input[type=file]').getAttribute("value");
	element.parentElement.parentElement.previousSibling.querySelector('input[type=file]').setAttribute('name',namep);
	element.parentElement.parentElement.previousSibling.querySelector('input[type=file]').setAttribute('value',valuep);
	element.parentElement.parentElement.querySelector('input[type=file]').setAttribute('name',pname);
	element.parentElement.parentElement.querySelector('input[type=file]').setAttribute('value',pvalue);
	//
	const changenode= element.parentElement.parentElement.previousSibling.cloneNode(true);
	const node= element.parentElement.parentElement.cloneNode(true);
	 element.parentElement.parentElement.parentElement.replaceChild(node, element.parentElement.parentElement.previousSibling);
	element.parentElement.parentElement.parentElement.replaceChild(changenode,element.parentElement.parentElement);
  }
  
  function fn_down(element){
	
	//넘버변경
	const nname=element.parentElement.parentElement.nextSibling.querySelector('input[type=file]').getAttribute("name");
	const nvalue=element.parentElement.parentElement.nextSibling.querySelector('input[type=file]').getAttribute("value");
	const namen=element.parentElement.parentElement.querySelector('input[type=file]').getAttribute("name");
	const valuen=element.parentElement.parentElement.querySelector('input[type=file]').getAttribute("value");
	element.parentElement.parentElement.nextSibling.querySelector('input[type=file]').setAttribute('name',namen);
	element.parentElement.parentElement.nextSibling.querySelector('input[type=file]').setAttribute('value',valuen);
	element.parentElement.parentElement.querySelector('input[type=file]').setAttribute('name',nname);
	element.parentElement.parentElement.querySelector('input[type=file]').setAttribute('value',nvalue);
	
	const changenode= element.parentElement.parentElement.nextSibling.cloneNode(true);
	const node= element.parentElement.parentElement.cloneNode(true);
	element.parentElement.parentElement.parentElement.replaceChild(node, element.parentElement.parentElement.nextSibling);
	element.parentElement.parentElement.parentElement.replaceChild(changenode,element.parentElement.parentElement);
	
  }
  