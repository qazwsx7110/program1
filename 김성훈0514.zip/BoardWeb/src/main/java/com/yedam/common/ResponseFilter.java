package com.yedam.common;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ResponseFilter implements Filter{

	String resp;
	
	@Override
	public void init(FilterConfig config) throws ServletException {
		resp = config.getInitParameter("response");
	}
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		
		
		//request.getServletContext().getContextPath();
		HttpServletRequest hrequest = (HttpServletRequest) request;
		String url = hrequest.getRequestURI();
		String context= hrequest.getContextPath();
		String path = url.substring(context.length());
		System.out.println(resp.indexOf(path));
		if(resp.indexOf(path)!=-1) {
			request.setAttribute("logPath", "/logForm.do");
			//((HttpServletResponse)response).sendRedirect("logForm.do");
		}
		
		
		
		chain.doFilter(request, response);
				
	}

	

	
}
