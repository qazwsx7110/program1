package com.yedam.common;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TotalCountControl implements Control {

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
       String bno = req.getParameter("bno");
       
       //service,mapper
       int cnt=10;
       //{"totalCout":10}
       resp.getWriter().print("{\"totalCout\":"+cnt+"}");
       
	}

}
