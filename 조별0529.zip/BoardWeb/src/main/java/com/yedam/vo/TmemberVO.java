package com.yedam.vo;

import java.util.Date;

import lombok.Data;

@Data
public class TmemberVO {

	private String memid;
	private String pw;
	private String memname;
	private String phone;
	private String emil;
	private Date birth;
	
	
}
