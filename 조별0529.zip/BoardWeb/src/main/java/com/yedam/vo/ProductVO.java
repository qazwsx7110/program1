package com.yedam.vo;

import java.util.Date;

import lombok.Data;

@Data
public class ProductVO {

	private int productcode;
	private String productname;
	private int price;
	private Date adddate;
	private String maincategory;
	private String subcategory;
	private String productimg;
	
	
	
}
