package com.yedam.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yedam.common.Control;
import com.yedam.service.ProductService;
import com.yedam.service.ProductServicelmpl;
import com.yedam.vo.ProductVO;

public class TImageDownloadControl implements Control {

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("utf-8");
		System.out.println(req.getParameter("productcode"));
		
		ProductService productaervice = new ProductServicelmpl();
		ProductVO product = new ProductVO();
		product = productaervice.getProduct(Integer.parseInt(req.getParameter("productcode")));
		
		
		File image = new File(req.getServletContext().getRealPath("images")+"/"+product.getProductcode()+"/title/"+product.getProductimg());
		
		System.out.println(image.getName());

		OutputStream out = resp.getOutputStream();

		resp.setHeader("Cache-Control", "no-cache");
		
		FileInputStream in = new FileInputStream(image);
		byte[] buffer = new byte[1024 * 8];
		while (true) {
			int count = in.read(buffer); 
			if (count == -1) 
				break;
			out.write(buffer, 0, count);
		}
		in.close();
		out.close();
		
	}

}
