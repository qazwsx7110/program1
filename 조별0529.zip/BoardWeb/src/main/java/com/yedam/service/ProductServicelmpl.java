package com.yedam.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.yedam.common.DataSource;
import com.yedam.mapper.MemberMapper;
import com.yedam.mapper.ProductMapper;
import com.yedam.vo.CimageVO;
import com.yedam.vo.OptionVO;
import com.yedam.vo.ProductVO;

public class ProductServicelmpl implements ProductService{

	SqlSession session = DataSource.getInstance().openSession(true);
	ProductMapper mapper = session.getMapper(ProductMapper.class);
	
	@Override
	public boolean addCimages(CimageVO cimage) {
		return  mapper.addCimages(cimage) == 1;
		
		
	}

	@Override
	public boolean addProduct(ProductVO product) {
		// TODO Auto-generated method stub
		return mapper.addProduct(product) == 1;
	}

	@Override
	public boolean addOption(OptionVO option) {
		// TODO Auto-generated method stub
		return mapper.addOption(option) == 1;
	}

	@Override
	public List<CimageVO> getCimages(int productcode) {
		// TODO Auto-generated method stub
		return mapper.getCimages(productcode);
	}

	@Override
	public ProductVO getProduct(int productcode) {
		// TODO Auto-generated method stub
		return mapper.getProduct(productcode);
	}

	@Override
	public List<OptionVO> getOptions(int productcode) {
		// TODO Auto-generated method stub
		return mapper.getOption(productcode);
	}

	@Override
	public boolean modifyProduct(ProductVO product) {
		// TODO Auto-generated method stub
		return mapper.modifyProduct(product)==1;
	}

	@Override
	public boolean deleteOption(int productcode) {
		// TODO Auto-generated method stub
		return mapper.deleteOption(productcode)==1;
	}

	@Override
	public String getTimages(int productcode) {
		// TODO Auto-generated method stub
		return mapper.getProductimg(productcode);
	}

	@Override
	public boolean updateTimages(ProductVO producttimage) {
		// TODO Auto-generated method stub
		
		return mapper.updateTimage(producttimage)==1;
	}

	@Override
	public boolean updateTimages2(CimageVO cimage) {
		// TODO Auto-generated method stub
		return mapper.updateTimage2(cimage)==1;
	}

	@Override
	public CimageVO getCimage(int productcode, int cimageorder) {
		// TODO Auto-generated method stub
		return mapper.getCimage(productcode, cimageorder);
	};
	
	
	
	
	
}
