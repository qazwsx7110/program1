const process = require('process');
const os = require('os');

//import  process  from 'process';
//프로세스 이벤트

process.on('beforeExit', (code)=>{
  console.log('2. 종료 직전 ', code)
})

process.on('exit', (code)=>{
  console.log('3. 종료될 때 ', code)
})
//process.exit();
console.log('1. 첫번째 메시지');
//console.log(process.env);
console.log('hostname', os.hostname());
console.log('type', os.type());
console.log('homedir', os.homedir());

//end