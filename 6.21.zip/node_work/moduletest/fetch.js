const axios = require('axios');
let url = 'http://localhost:3000/posts';

let data =  { "id": "5", "title": "test axios update" }
axiosput();   //호이스팅(끌어올리기)

function axiosput(){
  
}

//fetch put(수정)
function fetchput(){
  fetch(url+"/5", {
    method : "put",
    headers : {"content-type" : "application/json; charset=UTF-8"},
    body :JSON.stringify(data)
  })
  .then( response => response.json())
  .then( json => console.log(json))
  .catch(err=> console.log(err));
}

// axios post
function axiospost() {
  axios.post(url, data)
  .then( json => console.log(json))
}

//fetch post
function fetchpost(){
  fetch(url, {
    method : "post",
    headers : {"content-type" : "application/json; charset=UTF-8"},
    body :JSON.stringify(data)
  })
  .then( response => response.json())
  .then( json => console.log(json))
  .catch(err=> console.log(err));
}

//fetch get
function fetchget(){
  fetch(url)
  .then( response => response.json())
  .then( json => console.log(json))
} 

//axios get
function axiosget(){
  axios.get(url)
  .then( json => console.log(json.data))
}
