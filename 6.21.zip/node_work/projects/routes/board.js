const express = require('express');
const router = express.Router()

//let no = 2;
board = [{
  "no" : 1,
  "title": "json title",
  "writer": "hong",
  "content": "content test"
},
{
  "no" : 2,
  "title": "json title2",
  "writer": "hong",
  "content": "content test2"
}];

router.get("/", (req,res)=>{
  console.log(new Date(req.requestTime).toLocaleString());
  res.send(board)
})

router.get("/:no", (req,res)=>{
  console.log('no:', req.params.no)
  const no = req.params.no;
  let result = board.find(_______);
  res.send(result)
})
router.post("/", (req,res)=>{
  console.log(req.body);
  board.push(req.body)
  res.send("board insert 라우트 ")
})
router.put("/:no", (req,res)=>{
  const no = req.params.no;
  board = board.map(obj => obj.no == no ? {...obj, ...req.body } : obj )
  res.send("board update 라우트 ")
})
router.delete("/:no", (req,res)=>{
  //indexOf -> splite, 
  //board = board.filter 
  board = board.filter(obj => obj.no != no )
  res.send("board delete 라우트 ")
})

module.exports = router;