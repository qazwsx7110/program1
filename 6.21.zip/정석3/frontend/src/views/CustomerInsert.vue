<template>
      <div class="mb-3">
        <label for="id" class="form-label">name</label>
        <input type="text" v-model="customer.id" :disabled="customer.id==''" class="form-control" id="id" placeholder="name@example.com">
      </div> 
      <div class="mb-3">
        <label for="email" class="form-label">name</label>
        <input type="email" v-model="customer.email" class="form-control" id="email" placeholder="name@example.com">
      </div>      
      <div class="mb-3">
        <label for="name" class="form-label">Email address</label>
        <input type="text" v-model="customer.name"  class="form-control" id="name" placeholder="홍길동">
      </div>      
      <div class="mb-3">
        <label for="phone" class="form-label">phone</label>
        <input type="text" v-model="customer.phone"  class="form-control" id="phone" placeholder="011-1111-2222">
      </div>     
      <div class="mb-3">
        <label for="address" class="form-label">address</label>
        <input type="text" v-model="customer.address"  class="form-control" id="address" placeholder="011-1111-2222">
      </div>
      <button class="btn btn-success" @click="save">등록</button>
      <button class="btn btn-info" @click="save">초기화</button>
      <button class="btn btn-warning" @click="save">삭제</button>
      {{customer  }}
      {{customerdata  }}
</template>
<script>
  import axios from "axios"
  export default {
    props : {
      customerdata :{type:Object}
    },
    data(){ 
      return {  customer: { ...this.customerdata}   }; 
    },
    watch :{
      customerdata(newQuestion, oldQuestion) {
        this.customer = {...newQuestion};
      }
    },
    methods: {
      save(){
        if(check()) {
          axios.post("/customer", this.customer)
          .then(result => this.$router.push("/customer"));
        }
      },
      check(){
        if(! this.customer.name ){
          alert('이름입력')
          return  false;
        }
        else if(this.customer.email == ''){
          alert('이메일입력')
          return  false;
        }

        return true;
      }
    }
  }
</script>
<style></style>