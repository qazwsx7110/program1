<template>
  <div>inject : {{ itemlength }}</div>
</template>
<script>
  export default {
    inject : [ 'itemlength' ]
  }
</script>
