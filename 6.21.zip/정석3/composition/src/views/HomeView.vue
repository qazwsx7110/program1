<template>
  <div class="home">
    <LifeCycle></LifeCycle>
  </div>
</template>
<script>
import LifeCycle from "../components/watch2.vue";
export default {
  name: "HomeView",
  components: { LifeCycle },
};
</script>
