create table tbl_product (
  prod_code char(4) primary key, -- P001, P002, P003...
  prod_name varchar2(100) not null, -- 상품이름.
  prod_desc varchar2(500) not null, -- 상품의 설명.
  price number not null, -- 상품의 원래가격.
  off_price number not null, -- 할인된 가격.
  like_it number default, 3 -- 1 ~ 5점의 평점.
  prod_image varchar2(100)
);

insert into tbl_product (prod_code ,prod_name , prod_desc , price , off_price ,like_it ,prod_image )
values(1,'과테말라 안티구아','1',20,10,5,'과테말라 안티구아');
insert into tbl_product (prod_code ,prod_name , prod_desc , price , off_price ,like_it ,prod_image )
values(2,'니카라구아 원두','2',20,10,5,'니카라구아 원두');
insert into tbl_product (prod_code ,prod_name , prod_desc , price , off_price ,like_it ,prod_image )
values(3,'브라질 산토스','3',20,10,5,'브라질 산토스');
insert into tbl_product (prod_code ,prod_name , prod_desc , price , off_price ,like_it ,prod_image )
values(4,'에티오피아 예가체프','4',20,10,5,'에티오피아 예가체프');
insert into tbl_product (prod_code ,prod_name , prod_desc , price , off_price ,like_it ,prod_image )
values(5,'케냐 오크라톡신','5',20,10,5,'케냐 오크라톡신');
insert into tbl_product (prod_code ,prod_name , prod_desc , price , off_price ,like_it ,prod_image )
values(6,'코스타리카 따라주','6',20,10,5,'코스타리카 따라주');