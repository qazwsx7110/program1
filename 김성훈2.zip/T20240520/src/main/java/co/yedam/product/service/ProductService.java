package co.yedam.product.service;

import java.util.List;

import co.yedam.product.ProductVO;



public interface ProductService {

	ProductVO Product(int pno);
	List<ProductVO> ProductList();
	List<ProductVO> relatedProductList(int pno);
}
