package co.yedam.product.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.yedam.common.Command;
import co.yedam.product.ProductVO;
import co.yedam.product.service.ProductService;
import co.yedam.product.service.ProductServiceImpl;

public class ProductInfoControl implements Command {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		
		
		String no = req.getParameter("pno");
		ProductService svc = new ProductServiceImpl();
		ProductVO Product = svc.Product(Integer.parseInt(no));

		
		req.setAttribute("product", Product);
		
		List<ProductVO> list = svc.relatedProductList(Integer.parseInt(no));

		req.setAttribute("list", list);
		
		String path = "product/productInfo.tiles";
		
			req.getRequestDispatcher(path).forward(req, res);
		
	}

}
