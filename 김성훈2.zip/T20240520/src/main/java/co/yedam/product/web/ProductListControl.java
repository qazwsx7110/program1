package co.yedam.product.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.yedam.service.BoardService;
import com.yedam.service.BoardServiceImpl;
import com.yedam.service.ReplyService;
import com.yedam.service.ReplyServiceImpl;
import com.yedam.vo.BoardVO;
import com.yedam.vo.CartVO;

import co.yedam.common.Command;
import co.yedam.product.ProductVO;
import co.yedam.product.service.*;

public class ProductListControl implements Command {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
		
		
		ProductService svc = new ProductServiceImpl();
		List<ProductVO> list = svc.ProductList();

		req.setAttribute("list", list);
		
		String path = "product/productList.tiles";
		
			
				req.getRequestDispatcher(path).forward(req, res);
			
		
	}

}
