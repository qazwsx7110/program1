package com.yedam.web;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.yedam.common.Control;
import com.yedam.service.ReplyService;
import com.yedam.service.ReplyServiceImpl;
import com.yedam.vo.BoardVO;
import com.yedam.vo.ReplyVO;

public class ModifyReplyControl implements Control {

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("utf-8");
		
		String replyNo = req.getParameter("rno");
		String content= req.getParameter("reply");

		ReplyVO reply = new ReplyVO();
		reply.setBoardNo(Integer.parseInt(replyNo));
		reply.setReply(content);

		ReplyService svc = new ReplyServiceImpl();
		 // 한글encoding처리.
		if (svc.modifyReply(reply)==1) { // 수정...
			
			Gson gson = new GsonBuilder().create();
			String json = gson.toJson(reply);

			resp.getWriter().print(json);
			System.out.println(json);																			// string)
		} else {
			System.out.println("처리중 에러.");

		}
	}

}
