/*data.js*/
const data = {
    data : function(){
        return { 
            product: '양말',
            description : '등산양말',
            image : 'assets/images/socks_blue.jpg'
            
        }
    }
}