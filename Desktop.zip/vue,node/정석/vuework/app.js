const template = `      <header>
<h1 v-text="sitename"></h1>
</header>`;

export default {
  template,
  components: {},
  data() {
    return { sitename: "냥이애완용품샵" };
  },
};
