//component.js

let component = {
  name: "",

  template: ``,
  components: {},

  data() {
    return {};
  },
  computed: {},
  watch: {},

  setup() {},
  created() {},
  mounted() {},

  methods: {},
};

export default component;
