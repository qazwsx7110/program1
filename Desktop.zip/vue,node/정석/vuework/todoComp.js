const template = `<li :class="{checked: todo.completed}" @click="todoCheck(index)">
{{todo.title}}<span @click="todoDelete(index)" class="close">X</span></li>`;

export default {
  template,
  props: ["idx", "todo"],
  methods: {
    todoCheck(idx) {
      this.$emit("todoCheck", idx, "체크");
    },
    todoDelete(idx) {
      this.$emit("todoDelete", idx, "삭제");
    },
  },
  created() {
    // props는 `this`에 노출됩니다.
    console.log(this.idx);
    console.log(this.todo);
  },
};
