const app = Vue.createApp({
    data(){
        return {cart:0}
    },
    method : {
        updateCart() {
            this.cart += 1
        }
    }
})
