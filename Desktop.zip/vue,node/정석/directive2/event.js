//event.js
let template = `
<div>
    <button type="button"
 		v-on:click="upCounter(), printMsg($event)">Add 1</button>
    <p> The counter is : {{ counter }}</p>
    <hr>
    <input type="number" v-model="num">
    <button type="button"
 		v-on:click="increseCounter(num)">Add {{ num }}</button>
    <p> The counter is : {{ sum }}</p>
    <hr>
    <form style="border : 1px solid black;" 
            v-on:click="showAlert('form')">
    	<div style="border : 1px solid black;"
                v-on:click.self="showAlert('div')">
    		<p style="border : 1px solid black;"
                v-on:click.once="showAlert('p')">
    			<a style="border : 1px solid black;"
                    href="http://www.naver.com"
                    v-on:click.prevent
                    >네이버</a>
    		</p>
    		click div tag
    	</div>
    </form>
    <hr>
    <input type="text" 
    		v-model="keyword"
    		@keyup.enter="showAlert(keyword)">
</div>
`;

export default{
    template,
    data(){
        return {
            counter : 0,
            num : 0,
            sum : 0,
            keyword :''
        }
    },
    methods : {
        upCounter(event){
            console.log(event);
            this.counter += 1;
        },
        printMsg(event){
            console.log(event);
        },
        increseCounter(data){
            this.sum += data;
        },
        showAlert(tag){
            alert('click ' + tag);
        }
    }
}