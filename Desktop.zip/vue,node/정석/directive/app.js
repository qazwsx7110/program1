import headers from './header.js';
import databinding from './dataBinding.js';
import fors from './for.js';

const { createApp } = Vue
const template = /*html*/` <div>
                              <headers/>
                              <fors/>                             
                           </div>`
//vue 인스턴스 생성
const component = {
  template ,
  name : "모듈연습",
  components : {headers, databinding, fors},
  data(){ return { name:'홍길동', msg:'안녕하세요~~~~'  } },
  methods : {
     funca(){},
  },
  created(){    },
  mounted(){    },
  computed : { 
     fullname(){},
  }
}
createApp(component).mount("#app");