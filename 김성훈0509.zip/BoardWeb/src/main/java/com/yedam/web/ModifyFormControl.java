package com.yedam.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yedam.common.Control;
import com.yedam.service.BoardService;
import com.yedam.service.BoardServiceIml;
import com.yedam.vo.BoardVO;

public class ModifyFormControl implements Control {

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 String bro = req.getParameter("bro");
			
			BoardService svc = new BoardServiceIml();
			BoardVO vo =svc.getBoard(Integer.parseInt(bro));
			
			req.setAttribute("boardList", vo);
			
			req.getRequestDispatcher("").forward(req, resp);
	}

}
