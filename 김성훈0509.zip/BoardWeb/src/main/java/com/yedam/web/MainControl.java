package com.yedam.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.yedam.common.Control;
import com.yedam.common.DataSource;
import com.yedam.mapper.BoardMapper;
import com.yedam.service.BoardService;
import com.yedam.service.BoardServiceIml;
import com.yedam.vo.BoardVO;
import com.yedam.vo.EmployeeVO;

public class MainControl implements Control {
	
	
	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException  {
		System.out.println("Main 호출됨.");
       String path = "WEB-INF/board/boardList.jsp";
		
		BoardService svc = new BoardServiceIml();
		List<BoardVO> list = svc.boardList();
		
		req.setAttribute("boardList", list);
		
		req.getRequestDispatcher(path).forward(req, resp);
		
		
	}
}