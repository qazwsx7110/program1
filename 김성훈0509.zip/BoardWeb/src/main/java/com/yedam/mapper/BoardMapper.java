package com.yedam.mapper;

import java.util.List;

import com.yedam.vo.BoardVO;

public interface BoardMapper {
List<BoardVO> boardList();
int insertBoard(BoardVO board);
BoardVO selectBoard(int boaradNO);
int updateViewCnt(int boardNo);
//int updateViewCnt(iBoardVO board);
int deleteBoard(int boardNo);
}
