package com.yedam.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yedam.common.Control;
import com.yedam.service.ProductService;
import com.yedam.service.ProductServicelmpl;
import com.yedam.vo.CimageVO;

public class CImageDownloadControl implements Control{

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("utf-8");
		System.out.println("이미지다운 상품코드"+req.getParameter("productcode"));
		System.out.println("이미지다운 순서"+req.getParameter("cimageorder"));
		
		ProductService productaervice = new ProductServicelmpl();
		CimageVO cimage = new CimageVO();
		cimage = productaervice.getCimage(Integer.parseInt(req.getParameter("productcode")), Integer.parseInt(req.getParameter("cimageorder")));
		
		System.out.println("보낼 이미지 번호:"+cimage.getCimagename());
		System.out.println("보낼 이미지 순서:"+cimage.getCimageorder());
		
		File image = new File(req.getServletContext().getRealPath("images")+"/"+cimage.getProductcode()+"/"+cimage.getCimagename());
		
		OutputStream out = resp.getOutputStream();

        resp.setHeader("Cache-Control", "no-cache");
		
		FileInputStream in = new FileInputStream(image);
		byte[] buffer = new byte[1024 * 8];
		while (true) {
			int count = in.read(buffer); 
			if (count == -1) 
				break;
			out.write(buffer, 0, count);
		}
		in.close();
		out.close();
		
	}

}
