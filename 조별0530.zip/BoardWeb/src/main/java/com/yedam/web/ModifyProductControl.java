package com.yedam.web;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.yedam.common.Control;
import com.yedam.service.ProductService;
import com.yedam.service.ProductServicelmpl;
import com.yedam.vo.CimageVO;
import com.yedam.vo.OptionVO;
import com.yedam.vo.ProductVO;

public class ModifyProductControl implements Control{

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ProductService productservice = new ProductServicelmpl();
		
		int maxSize = 5 * 1024 * 1024;
		
		String savePath = req.getServletContext().getRealPath("images")+"/temp";
		

		File Folder = new File(req.getServletContext().getRealPath("images")+"/temp");
		//임시폴더 생성
		if (!Folder.exists()) {
			try{
				Folder.mkdir(); //폴더 생성합니다.
				System.out.println("임시폴더가 생성되었습니다.");
			} 
			catch(Exception e){
				e.getStackTrace();
			}        
			
		}else {
			System.out.println("이미 폴더가 생성되어 있습니다.");
		}				
		//임시폴더 타이틀 생성
		
		File TitleFolder = new File(req.getServletContext().getRealPath("images")+"/temp"+"/title");
		if (!TitleFolder.exists()) {
			try{
				TitleFolder.mkdir(); //폴더 생성합니다.
				System.out.println("타이틀폴더가 생성되었습니다.");
			} 
			catch(Exception e){
				e.getStackTrace();
			}        
			
		}else {
			System.out.println("이미 타이틀폴더가 생성되어 있습니다.");
		}
		
		//
		MultipartRequest mr = new MultipartRequest(req, savePath, maxSize, "utf-8"//
				, new DefaultFileRenamePolicy());		
		
		ProductVO product=new ProductVO();
		
		System.out.println(mr.getParameter("pcode"));
		System.out.println(mr.getParameter("productname"));
		System.out.println(mr.getParameter("price"));		
				
		product.setProductcode(Integer.parseInt(mr.getParameter("pcode")));
		product.setProductname(mr.getParameter("pname"));
		product.setPrice(Integer.parseInt(mr.getParameter("price")));
				
		productservice.modifyProduct(product);
		productservice.deleteOption(Integer.parseInt(mr.getParameter("pcode")));
		
		//옵션등록						
		String[] options=mr.getParameterValues("option");
		for(int i = 0; i< options.length; i++){ 
			System.out.println(options[i]);
		    } 
		String[] oprices=mr.getParameterValues("oprice");
		for(int i = 0; i< oprices.length; i++){ 
			System.out.println(oprices[i]);
		    }
				
		OptionVO option= new OptionVO();
		for(int i = 0; i< options.length; i++) {
			option.setOptioncode(i);
			option.setOptionname(options[i]);
			option.setOptionprice(Integer.parseInt(oprices[i]));
			option.setProductcode(Integer.parseInt(mr.getParameter("pcode")));
			productservice.addOption(option);
			
		}								
		        //이미지파일여부
				File OldFolder = new File(req.getServletContext().getRealPath("images")+"/"+mr.getParameter("pcode"));
				if (!OldFolder.exists()) {
					try{
						OldFolder.mkdir(); //폴더 생성합니다.
						System.out.println("이미지폴더가 생성되었습니다.");
					} 
					catch(Exception e){
						e.getStackTrace();
					}        
					
				}else {
					System.out.println("이미 이미지폴더가 생성되어 있습니다.");
				}		
				//타이틀파일여부
				File OldTitleFolder = new File(req.getServletContext().getRealPath("images")+"/"+mr.getParameter("pcode")+"/title");
				if (!OldTitleFolder.exists()) {
					try{
						OldTitleFolder.mkdir(); //폴더 생성합니다.
						System.out.println("타이틀폴더가 생성되었습니다.");
					} 
					catch(Exception e){
						e.getStackTrace();
					}        
					
				}else {
					System.out.println("이미 타이틀폴더가 생성되어 있습니다.");
				}
				
				Iterator<String> fileNames=(Iterator<String>) mr.getFileNames();
				//타이틀사진 변경여부
				boolean title=false;
				
				try {
					
					while(fileNames.hasNext()){
						String fileName = fileNames.next();	
						if(mr.getFile(fileName)!=null) {	
							String filename2 = mr.getFile(fileName).getName();
						
							//타이틀파일변경시
							if(fileName.equals("title")) {
								//파일업데이트
								
								ProductVO tproduct= new ProductVO();
								tproduct.setProductcode(Integer.parseInt(mr.getParameter("pcode")));
								tproduct.setProductimg(filename2);
								
								CimageVO timag= new CimageVO();
								timag.setCimagename(filename2);
								timag.setProductcode(Integer.parseInt(mr.getParameter("pcode")));
								productservice.updateTimages(tproduct);
								productservice.updateTimages2(timag);
								//
								try {
									File file = FileUtils.getFile(Folder+"/"+filename2);
									File fileToMove = FileUtils.getFile(TitleFolder+"/"+filename2);
									FileUtils.moveFile(file, fileToMove);
									title=true;
									
								} catch (IOException e) {
									e.printStackTrace();
								}		
								
							}
							
							
							
						}
						
					}
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//타이틀변경 없을시 타이틀 파일 옮김
				if(!title) {
					
					
					String titlefilename = productservice.getTimages(Integer.parseInt(mr.getParameter("pcode")));
					System.out.println("타이틀이름값"+titlefilename);
					if(!titlefilename.equals("null")) {
					File file = FileUtils.getFile(OldTitleFolder+"/"+titlefilename);
					File fileToMove = FileUtils.getFile(TitleFolder+"/"+titlefilename);
					FileUtils.moveFile(file, fileToMove);
					}
				}
				
				//옛 파일 삭제
				File file = FileUtils.getFile(OldFolder);
				FileUtils.cleanDirectory(file);
				file.delete();
								
				File renameFile = new File(req.getServletContext().getRealPath("images")+"/"+mr.getParameter("pcode"));
				Folder.renameTo(renameFile);
				
				
				
		
	}

}
