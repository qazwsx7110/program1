/**
 * board.js
 */
// 수정버튼
document.querySelector('#modBtn').addEventListener('click', function(){
	document.forms.myForm.action = "modBoardForm.do"; // 수정
	document.forms.myForm.submit(); // submit 이벤트 호출
	
})

// 삭제버튼
document.querySelector('.btn-danger').addEventListener('click', function(){
	document.forms.myForm.action = "/removeBoardForm.do"; // 삭제
	document.forms.myForm.submit();
})


 