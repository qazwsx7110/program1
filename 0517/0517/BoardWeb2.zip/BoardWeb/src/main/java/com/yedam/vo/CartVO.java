package com.yedam.vo;

import lombok.Data;

@Data
public class CartVO {
	private int no;
	private String productNm;
	private int price;
	private int qty;
}
