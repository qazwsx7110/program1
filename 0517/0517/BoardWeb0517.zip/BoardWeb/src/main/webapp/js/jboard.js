/**
 * jboard
 */

$('#modBtn').on('click', function() {
	document.forms.myFrm.action = "modBoardForm.do";
	document.forms.myFrm.submit();
})

$('.btn-danger').on('click', function() {
	document.forms.myFrm.action = "deleteForm.do";
	document.forms.myFrm.submit();
})

let page = 1;
showList();
function showList() {
	// 새로운 목록을 출력할 경우에 기존 목록 지우기
	$('div content ul li:gt(2)').remove();

	svc.replyList({ bno: bno, page: page },
		result => {
			result.forEach(reply => {
				const row = makeRow(reply);
				row.appendTo('div.reply ul');
			})
		},
		err => { console.log(err) })

	function makeRow(reply = {}) {
		let tmpl = $('div.reply li:nth-of-type(3)').clone();
		tmpl.css('display', 'block');
		tmpl.on('dblclick', function(e){
			$('#myModal').css('display', 'block');
			let replyNo = $(e.target).parent().children().eq(0).text();
			let reply = $(e.target).parent().children().eq(1).text();
			$('#myModal p:eq(0)').text('댓글번호: ' + replyNo);
			$('#myModal input[name="modal_reply"]').val(reply);		
		})
		tmpl.attr('data-rno', reply.replyNo);
		tmpl.find('span:eq(0)').text(reply.replyNo);
		tmpl.find('span:eq(1)').text(reply.reply);
		tmpl.find('span:eq(2)').text(reply.replyer);
		return tmpl;
	} // end of makeRow()

	function deleteRow(e) {
		const rno = $(e.target).parent().parent().data('rno');

		svc.removeReply(rno
			, result => {
				if (result.retCode == 'OK') {
					alert('삭제완료');
					showList();

				} else if (result.retCode == 'NG') {
					alert('삭제 실패');
				} else {
					alert('알 수 없는 반환값')
				}
			} // param2
			, err => console.log(err)
		)

	} // end of deleteRow()
	$('#addReply').on('click', function() {

		svc.addReply({ bno, writer, reply }
			, result => {
				if (result.retCode == 'OK') {
					page = 1;
					showList();

					$('#reply').val("");
				}
			}
			, err => console.log(err)
		);
	})
	// 페이징 생성
	let pagination = $('div.pag')

	prev = startPage > 1;
	next = endPage < realEnd;

	// a 태그 생성
	pagination.html('');
	// 이전페이지 여부
	if (prev) {
		let aTag = $('<a>&laquo;</a>')
			.attr('href', '#')
			.attr('data-page', startPage - 1);
		aTag.on('click', function(e) {
			e.preventDefault();
			page = $(e.target).data('page');
			showList();
		})
		aTag.appendTo(pagination);
	}
	for (let pg = startPage; pg <= endPage; pg++) {
		let aTag = $('<a />').html(pg)
			.attr('data-page', pg)
			.attr('href', pg);
		if (pg == page) {

			aTag.addClass('active');
		}
		aTag.on('click', function(e) {
			e.preventDefault();
			page = e.target.dataset.page;
			showList();
		})
		pagination.append(aTag);
	}
} // end of createPageList

// 수정기능 추가
$('.modal-content button').on('click', function(){
	alert('수정완료');
	$('#myModal').css('display', 'none');
	showList();
})
