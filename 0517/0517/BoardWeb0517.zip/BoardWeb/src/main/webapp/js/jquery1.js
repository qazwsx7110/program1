/*
	jquery1.js
*/

//document.addEventListener("DOMContentLoaded", initForm);

// 페이지가 로드가 다 되면 함수를 실행
$(document).ready(function() {
	// 버튼삭제
	$('tbody button').on('click', delRow);
	
	$('#addBtn').on('click', function() {
		// 2개 값을 td생성. tr생성 tbody 하위요소 추가.

		// tr 생성 append = appendChild, text = innerText 값을 읽을떄는 val
		let inputName = $('input[name="name"]');
		let inputScore = $('input[name="score"]');
		// 가지고 있는 값(val)을 비교 inputname는 x, 함수 종료 return
		if (!inputName.val()) {
			alert('값을 입력하세요.');
			return;
		}
		let tr = $('<tr />').append(
			// attr = setAttribute
			$('<td />').append($('<input /> ').attr('type', 'checkbox')),
			$('<td />').text(inputName.val()),
			$('<td />').text(inputScore.val()),
			$('<td />').append($('<button>삭제</button>').on('click', delRow))
		);
		$('#list tbody').append(tr);

		// 값을 읽고 비워주기
		inputName.val('');
		inputScore.val('');
	})
});

// 이벤트가 매개값으로 전달 이벤트를 받는 대상 => e.target (button)
function delRow(e){
	// parentElement = parent
	$(e.target).parent().parent().remove();
}