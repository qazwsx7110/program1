/**
 * 
 */
 function selectFile(element) {

        const file = element.files[0];
        const filename = element.closest('.file_input').firstElementChild;

        // 1. 파일 선택 창에서 취소 버튼이 클릭된 경우
        if ( !file ) {
            filename.value = '';
            return false;
        }

        // 2. 파일 크기가 10MB를 초과하는 경우
        const fileSize = Math.floor(file.size / 1024 / 1024);
        if (fileSize > 10) {
            alert('10MB 이하의 파일로 업로드해 주세요.');
            filename.value = '';
            element.value = '';
            return false;
        }

        
        
    }
    
    function fremoveFile(element) {     
        const filename = element.closest('.file1').firstElementChild;              
            filename.value = '';
            return false;        
    }

    // 파일 추가
    function addFile() {
		
		if(document.querySelector('.file_list').children.length<10){
		
        const fileDiv = document.createElement('div');
        
        document.querySelectorAll('.file_input').forEach(function (item, index, arr) {
			
			
			
			//item.setAttribute('name','selc3')
			 console.log(item.getAttribute('name'));
			
		})
        
        
     
		
        fileDiv.innerHTML =`
            <div class="file_input">
               
               
                    <input type="file" name="2" onchange="selectFile(this);" />
                
            <button type="button" onclick="removeFile(this);" class="btns del_btn"><span>삭제</span></button>

            </div>
        `;
        document.querySelector('.file_list').appendChild(fileDiv);
     
       
        }
        else{
			alert('10장 까지 등록이 가능합니다.');
			
		}
    }
    
    // 파일 삭제
    function removeFile(element) {
        const fileAddBtn = element.nextElementSibling;
        if (fileAddBtn) {
            const inputs = element.previousElementSibling.querySelectorAll('input');
            inputs.forEach(input => input.value = '')
            return false;
        }
        element.parentElement.parentElement.remove();
    }
