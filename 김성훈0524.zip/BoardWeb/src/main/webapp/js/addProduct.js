/**
 * 
 */
// 파일 선택
 var cnt=1;

   function fn_addFile(){
	 const fileDiv = document.createElement('div');
	fileDiv.innerHTML =`
	
	<div class="file_input">                             
              <img name="file" src="#" alt="your image"/>                
              <input type="file" name="`+cnt+`" onchange="viewFile(this)";/>
     </div>     
	`;		
	  document.querySelector('.file_list').appendChild(fileDiv);
	  cnt++;
  }  
  
  function readURL(input) {
 if (input.files && input.files[0]) {
  var reader = new FileReader();
  
  reader.onload = function (e) {
	console.log(input.parentElement.firstElementChild);
   input.parentElement.firstElementChild.setAttribute('src', e.target.result);  
  }
  
  reader.readAsDataURL(input.files[0]);
  }
}

 function viewFile(e) {
	readURL(e);
	
	
 }

