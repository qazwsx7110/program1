package com.yedam.mapper;

import com.yedam.vo.CimageVO;
import com.yedam.vo.OptionVO;
import com.yedam.vo.ProductVO;
import com.yedam.vo.ReplyVO;

public interface ProductMapper {

	int addProduct(ProductVO product);
	int addCimages(CimageVO cimage);
	int addOption(OptionVO option);
}
