package com.yedam.service;

import org.apache.ibatis.session.SqlSession;

import com.yedam.common.DataSource;
import com.yedam.mapper.MemberMapper;
import com.yedam.mapper.ProductMapper;
import com.yedam.vo.CimageVO;
import com.yedam.vo.OptionVO;
import com.yedam.vo.ProductVO;

public class ProductServicelmpl implements ProductService{

	SqlSession session = DataSource.getInstance().openSession(true);
	ProductMapper mapper = session.getMapper(ProductMapper.class);
	
	@Override
	public boolean addCimages(CimageVO cimage) {
		return  mapper.addCimages(cimage) == 1;
		
		
	}


	@Override
	public boolean addProduct(ProductVO product) {
		// TODO Auto-generated method stub
		return mapper.addProduct(product) == 1;
	}


	@Override
	public boolean addOption(OptionVO option) {
		// TODO Auto-generated method stub
		return mapper.addOption(option) == 1;
	};
}
