package com.yedam.service;

import com.yedam.vo.CimageVO;
import com.yedam.vo.OptionVO;
import com.yedam.vo.ProductVO;
import com.yedam.vo.TmemberVO;

public interface ProductService {
	boolean addCimages(CimageVO cimage);
	boolean addProduct(ProductVO product);
	boolean addOption(OptionVO option);
}
