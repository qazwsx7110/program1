package com.yedam.vo;

import java.util.Date;

import lombok.Data;

@Data
public class OptionVO {

	private int optioncode;;
	private int productcode;
	private String optionname;
	private int optionprice;
	
}
