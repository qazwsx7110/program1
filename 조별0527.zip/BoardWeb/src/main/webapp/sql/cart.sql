create table tbl_cart (
	no number primary key,
	product_nm varchar2(50),
	price number,
	qty number
);
insert into tbl_cart values(1, '과테말라 안티구아', 1200, 2);
insert into tbl_cart values(2, '케냐 오크라톡신', 1500, 2);
insert into tbl_cart values(3, '코스타리카 따라주', 1800, 2);
insert into tbl_cart values(4, '니카라구아 더치핸드드립', 2200, 2);
insert into tbl_cart values(5, '브라질산토스', 3200, 2);
insert into tbl_cart values(6, '에티오피아 예가체프', 3300, 2);

