/**
 * 
 */
// 파일 선택

 var optioncnt=1;

  function fn_addoption(){
	 const optionDiv = document.createElement('div');
	optionDiv.innerHTML =`
	
	<div class="option_input">                          
                            
              옵션이름<input type="text" name="option`+optioncnt+`" ;/>가격<input type="text" name="price`+optioncnt+` ";/>
     </div>     
	`;		
	  document.querySelector('.option_list').appendChild(optionDiv);
	 optioncnt++;
  }  
 
  
 
 var cnt=1;

   function fn_addFile(){
	 const fileDiv = document.createElement('div');
	fileDiv.innerHTML =`
	
	<div class="file_input">                             
              <img name="file" />                
              <input type="file" name="`+cnt+`" onchange="viewFile(this)";/>
     </div>     
	`;		
	  document.querySelector('.file_list').appendChild(fileDiv);
	  cnt++;
  }  
  
  function readURL(input) {
 if (input.files && input.files[0]) {
  var reader = new FileReader();
  
  reader.onload = function (e) {
	console.log(input.parentElement.firstElementChild);
   input.parentElement.firstElementChild.setAttribute('src', e.target.result);  
  }
  
  reader.readAsDataURL(input.files[0]);
  }
}

 function viewFile(e) {
	readURL(e);
	
	
 }

