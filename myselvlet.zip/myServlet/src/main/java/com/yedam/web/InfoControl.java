package com.yedam.web;

import com.yedam.common.Control;

public class InfoControl implements Control {

	@Override
	public void exec() {
		// TODO Auto-generated method stub
		System.out.println("info 호출됨.");
	}

}
