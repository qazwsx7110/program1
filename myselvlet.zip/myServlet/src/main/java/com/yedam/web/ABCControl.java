package com.yedam.web;

import com.yedam.common.Control;

public class ABCControl implements Control {

	@Override
	public void exec() {
		// TODO Auto-generated method stub
		System.out.println("abc 호출됨.");
	}

}
