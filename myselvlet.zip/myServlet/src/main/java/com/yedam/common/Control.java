package com.yedam.common;

public interface Control {
	public void exec();
}
