package com.yedam.vo;

import lombok.Data;

@Data
public class EmployeeVO {
	private int employeeId;
	private String firstName;
	private String lastName;
	private String email;
	private String jobId;
}
