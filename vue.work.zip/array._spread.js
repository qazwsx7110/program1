let arr1=[1,2]
let arr2=[3,4]
let arr3=[...arr1,...arr2]
console.log(arr[0])


const chars = ['sun','mon','thu',]