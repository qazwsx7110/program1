(function print(msg) {
    console.log(msg);

})('실행');


