/*

*/

function total(num,...arr){
    
    let sum=num;
    // for(let i=0;i<arr.length;i++){
    //  sum+=arr[i];
    // }
    // for(n of arr){
    //   result+=n;

    // }

    //  for(idx of arr){
    //    result+=arr[idx];

    //  }
    
    //reduse
     
    result= arr.reduce((acc,ele)=>acc+ele,num) 
     
    console.log('합체=',result);

}

total(10);
total(10,20);
total(10,20,30);