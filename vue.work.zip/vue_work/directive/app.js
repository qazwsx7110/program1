import headers from './header.js';
import footers from './footer.js';
import databinding from './dataBinding.js';
import ifs from './if.js';
import fors from './for.js';
import events from './event.js';
import posts from './post.js';

const {createApp} = Vue
const template = /*html*/`<div><headers/><posts/>
<footers/>
</div>`

const component ={
    template,
name: "모듈연습",
components:{headers,databinding,footers,ifs,fors,events,posts},
data(){return {name:'홍길동',msg:'안녕하세요~~~~~'}},
methods:{
    funca(){},
},
created(){},
mounted(){

},computed:{
    fullname(){},
}

}
createApp(component).mount("#app");
