const template=/*html*/`
<div>{{htmlString}}</div>
<div v-text="htmlString"></div>
<div v-html="htmlString"></div>
<!-- v-text,v-html 태그 내용 (바디) 바인딩--> 
<input type="text" class="form-control mb-3" v-model.trim="memINfo.valueModel">
<input type="number" class="form-control mb-3" v-model.number="memINfo.score">
<textarea v-model.lazy="memINfo.memo" class="form-control mb-3"></textarea>
<select v-model="memINfo.city" class="form-control mb-3">
<option value="02">서울</option>
<option value="21">부산</option>
<option value="064">제주</option>
</select>
<div class="form-check" mb-3>
<label class="form-check-label">서울</label>
<input type="radio" value="02" class="form-check-input"v-model="memINfo.picked">
</div>
<div class="form-check">
<label class="form-check-label">부산</label>
<input type="radio" value="21" class="form-check-input"v-model="memINfo.picked">
</div>
<div class="form-check">
<label class="form-check-label">제주</label>
<input type="radio" value="064" class="form-check-input"v-model="memINfo.picked">
</div>
<button class="btn btn-success" v-bind:disabled="memINfo.valueModel==''">등록</button>
<!-- v- bind 태그 속성 바인딩--> 
<img v-bind:src="memINfo.profile">
<!-- 클래스 바인딩-->
<div class="container mb-3" v-bind:class="{active:isActive,'text-red':hasError}">클래스 바인딩</div> 
<div class="container mb-3" v-bind:class="[activeClass,errorClass]">클래스 배열 바인딩</div>
<div class="container mb-3" v-bind:class="styleObject"> 인라인 스타일 바인딩</div>

<p>{{memINfo}}</p>
`

export default{
  template,
  data(){return {htmlString:/*html*/`<p style='color:red'>this is red String</p>`,
    memINfo:{valueModel : 'south korea',score:100,memo:"메모 작성",city:"064",mainYn:["02","21"],picked:"02",profile:"천.jpg"},isActive:true,hasError:false,activeClass:'active',errorClass:'text-red',
    styleObject:{color:'red',fontSize:'13px'}
  }},
  methods:{}

}