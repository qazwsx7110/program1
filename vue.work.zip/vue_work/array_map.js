let arr = [1,2,3]
let result =arr.map(a=>a*a);
console.log(result)

let userArr =[
    {userid:1,score:60},
    {userid:2,score:50},
    {userid:3,score:70},
    {userid:4,score:40},
]

let newArr=userArr.map(a=>{if(a.score>=60) return {...a,grade:true,score:100};
   else return {...a,grade:false};
});

console.log(userArr);
console.log(newArr);

// for(){
//     if(userSrr[i].score>=80){
//         newArr={...userArr[i],grade:true}
//     }
// }