
const svc = {
	
	cartList(param = {}, successCall, errorCall) {
		fetch('productList.do')
			.then(resolve => resolve.json()) // json -> 객체.
			.then(successCall)
			.catch(errorCall);
	}
	
}

let basket = {
	list: function() {
	
		 svc.cartList(
			result=>{				
				result.forEach(cart=>{
					
					const row =document.querySelector('div.col mb-5').childNodes(true);
		            row.style.display='block';
		            
		            row.querySelector('div.img').setAttribute('src','images/'+'케냐 오크라톡신'+'.jpg');
		           
		           
		          
		            document.querySelector('#basket').append(row);
		            
				})
				
			
			},err=>{
				
			console.log(err);	
			}
			
		 )
	}	
};

basket.list();
