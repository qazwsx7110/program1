package co.yedam.common;

import java.io.IOException;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.yedam.product.web.ProductInfoControl;
import co.yedam.product.web.ProductListControl;

//url: *.do로 끝나면 전부 여기로 들어와서 실행
public class FrontController extends HttpServlet {

	Map<String, Object> map = new HashMap<>();

	@Override
	public void init(ServletConfig config) throws ServletException {
		// 첫 페이지
		map.put("/productList.do", new ProductListControl());
		map.put("/productInfo.do", new ProductInfoControl());

	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 요청정보에 포함되어있는 한글을 인코딩방식 지정하기
		req.setCharacterEncoding("UTF-8");
		
		String uri = req.getRequestURI();
		String context = req.getContextPath();
		System.out.println("uri: " + uri + ", context: " + context);
		String path = uri.substring(context.length());
		System.out.println("path: " + path);

		Command controller = (Command) map.get(path);
		controller.execute(req, resp);

	}
}
