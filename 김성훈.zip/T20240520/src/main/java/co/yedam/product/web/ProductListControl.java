package co.yedam.product.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import co.yedam.common.Command;
import co.yedam.product.ProductVO;
import co.yedam.product.service.*;

public class ProductListControl implements Command {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) {
		

		ProductService svc = new ProductServiceImpl();
		List<ProductVO> list =svc.boardList();
		
		Gson gson = new GsonBuilder().create();
	
		
		try {
			res.getWriter().print(gson.toJson(list));
			System.out.print(gson.toJson(list));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String path = "product/productList.tiles";
		try {
			
			req.getRequestDispatcher(path).forward(req, res);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
