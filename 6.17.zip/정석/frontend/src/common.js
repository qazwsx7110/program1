import {reactive, computed, toRefs} from  'vue';
function plusCalulator(){
  let state = reactive({ 
    num1:20, 
    num2:20, 
    result: computed(()=> parseInt(state.num1) + parseInt(state.num2) )   
  });
  return toRefs(state);
}
export { plusCalulator }