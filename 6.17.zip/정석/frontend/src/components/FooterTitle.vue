<template>
  <slot></slot>
</template>
<script>

</script>