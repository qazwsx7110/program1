<template>
  <h2>고객관리</h2>
  <div class="row">
    <div  class="col-md-12 col-lg-7 border p-3">
      <div>
          <select v-model="pageUnit" @change="goPage(1)">
            <option>2</option>
            <option>5</option>
            <option>10</option>
          </select>
      </div>
      <table class="table table-striped table-hober">
        <tr :key="idx" v-for="(p, idx) in customers" @click="updateFormHandler(p)">
              <td>{{p.id}}</td>
              <td>{{p.name}}</td>
              <td>{{p.email}}</td>
              <td>{{p.phone}}</td>
          </tr>
      </table> 
      <PagingComponent v-bind="page" @go-page="goPage" /> 
    </div>
    <div  class="col-md-12 col-lg-5  border  p-3">
      <CustomerInsert 
      :customerdata="customer" 
      ref="customerForm"/>
    </div>
  </div>
</template>
<script>
  import PageMixin from '../mixin.js';
  import axios from "axios"   
  import PagingComponent from "@/components/PagingComponent.vue"
  import CustomerInsert from "@/views/CustomerInsert.vue"
  export default {
    mixins : [PageMixin],
    components : {PagingComponent, CustomerInsert},
  data(){ return {
    customers: [],
    customer: {},
    page :{},
    pageUnit :2
  }; },
  created(){ 
    this.goPage(1);
  },
  methods: {
    async goPage(page){
      let pageUnit= this.pageUnit;
      let result = await axios.get(`/api/customer?pageUnit=${pageUnit}&page=${page}`);
      this.customers = result.data.list;
      this.page = this.pageCalc(page, result.data.count, 5, pageUnit);
      console.log(this.page)
    },
    updateFormHandler(customer){
      this.customer = customer;  //==> props => data
      //this.$refs.customerForm.customer = {... customer};
    }
  
  }
  }
</script>
<style></style>