
<template>
  
<div>고객관리</div> 
  <div class="row">
    
    <div class ="col-md-12 col-lg-7 border p-3">
    <select v-model="pageUnit" @change="goPage(1)">
<option>2</option>
<option>5</option>
<option>10</option>
</select>
<table class="table table-splite table-hober">
<thead>
<tr>
<th>ID</th><th>이름</th><th>이메일</th><th>번호</th><th>주소</th>
</tr>
</thead>
<tbody>
<tr :key="customer" v-for="customer in customers" @click="updateFormHandler(customer)">
<td>{{customer.id}}</td>
<td>{{customer.name}}</td>
<td>{{customer.email}}</td>
<td>{{customer.phone}}</td>
<td>{{customer.address}}</td>
</tr>
</tbody>
</table>
<PagingComponent v-bind="page" @go-page="goPage"/>
</div>
    <div class ="col-md-12 col-lg-5 border">
      
      <div>
ID<input v-model="customer.id">
이름<input v-model="customer.name">
이메일<input v-model="customer.email">
폰번호<input v-model="customer.phone">
주소<input v-model="customer.address">
<button @click="add">등록</button>
<button @click="del">삭제</button>
<button @click="update">수정</button>
<button @click="reset">초기화</button>
</div> 
  
</div>

  </div>
</template>


  <script>
  // @ is an alias to /src
  import PageMixin from '../mixin.js'
  import PagingComponent from '@/components/PagingComponent.vue';
import axios from 'axios';
  const url="/api/customer";

  export default {
    props:{
      customerdata:{type:Object}
    },
        mixins:[PageMixin],
        components:{PagingComponent},     

        data(){return {
          customers:[],customer:{...this.customerdata},page:{},pageUnit:2
           
        }},
        watch:{
          customerdata(newQuestion,oldQuestion){
            this.customer={...newQuestion}
          }
        },

    created(){
        this.goPage(1);
        

    },
    methods:{
      async goPage(page){
        let pageUnit=this.pageUnit;
        let result =await axios.get(`/api/customer?pageUnit=${pageUnit}&page=${page}`);
      this.customers=result.data.list;
        this.page = this.pageCalc(page,result.data.count,5,pageUnit);
        console.log(this.page);
    },
    async add(){
      if(this.check()){
      await axios.post(url,this.customer)
        .then()
        this.goPage(1)
      }
    },
    async del(){
      await axios.delete(`${url}/${this.customer.id}`)
      .then()
      this.goPage(1)
    },
    async update(){
      await axios.put(url,this.customer)
      .then( )
      this.goPage(1)
    }
    ,
    updateFormHandler(customer){
      this.customer=customer; //==>props=>data
      // this.$refs.customerForm.customer={...customer};
    },
    reset(){
      this.customer={};
    },
    check(){
       if(!this.customer.name){
           alert('이름입력')
           return false;
       }
       else if(!this.customer.email){
        alert('이메일입력')
        return false;
       }
    }

  }
}
  </script>
  