<template>
    <div>{{x}},{{y}}</div>
    <input v-model="num1" >+
    <input v-model="num2" >=
    <span>{{result }}</span>
</template>

<script setup>
import {useMouse} from '../mouse'
import {plusCalulator} from '../common'
let {num1,num2,result}=plusCalulator();
const {x,y} = useMouse();

</script>