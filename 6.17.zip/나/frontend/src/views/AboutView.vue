<template>
  <PageTitle></PageTitle>
  <div class="about">
    <h1>This is an about page</h1>
  </div>
</template>

<script>
// @ is an alias to /src
import PageTitle from '@/components/pageTitle.vue'

export default {
  name: 'AboutView',
  components: {
    PageTitle
  },
  data(){
    
  }
}
</script>