import { createStore } from "vuex";
import persistedstate from "vuex-persistedstate";

const store =createStore({
    state(){
        return{  user: {},count:0 }
    },
    mutations:{
        user(state, data) {
            state.user = data;
          },
        increment(state){
            state.count++;
        }
    },
    plugins: [persistedstate({ paths: ["user"] })],
});

export default store;