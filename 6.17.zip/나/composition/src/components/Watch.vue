<template>
<p>
    예/아니오 질문:
    <input v-model="question" />
  </p>
  <p>{{ answer }}</p>


    <input type="text" v-model="name.firstname">
    <input type="text" v-model="name.lastname">

    <div>{{fullname}}</div>
    <input type="text" v-model="reactivename.firstname">
    <input type="text" v-model="reactivename.lastname">
    <div>{{fullname2}}</div>
</template>
<script setup>
import {ref,computed, watch } from 'vue';
let firstnam=ref("hong")
let lastName=ref("gin")
let fullName = computed(()=> firstName.value + ' ' + lastName.value);
let name = ref({firstName:'길동',lastName:'홍'})
let fullName2 = computed(()=>name.value.firstName+''+name.value.lastName);

let reactivename = ref({firstName:'길동',lastName:'홍'})
let fullName3 = computed(()=>reactivename.value.firstName+''+reactivename.value.lastName);

const question = ref('')
const answer = ref('질문에는 일반적으로 물음표가 포함됩니다.')

// watch는 ref에서 직접 작동합니다
watch(question, async (newQuestion, oldQuestion) => {
  if (newQuestion.indexOf('?') > -1) {
    answer.value = '생각 중...'
    try {
      const res = await fetch('https://yesno.wtf/api')
      answer.value = (await res.json()).answer === 'yes' ? '네' : '아니오'
    } catch (error) {
      answer.value = '에러! API에 연결할 수 없습니다. ' + error
    }
  }
})
</script>