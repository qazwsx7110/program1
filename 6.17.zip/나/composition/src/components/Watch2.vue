<template>
  <div>
    <input v-model="state.num1">
    <input v-model="state.num2">
    <div>{{ state.result }}</div>
    </div>

</template>

<script setup>
import {reactive,watch} from 'vue';
let state=reactive({num:0,num2:0, result:0})
watch(state,(newNum,oldNum)=>console.log(state.num))
watch(state,(newNum,oldNum)=>console.log(state.num2))
</script>