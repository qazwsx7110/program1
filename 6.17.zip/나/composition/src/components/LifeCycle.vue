<template>
    <div>LifeCycle</div>
    <Reactive></Reactive>
</template>
<script setup>
import { onMounted, onUpdated } from 'vue';
import { Reactive } from './Reactive.vue';
onMounted(()=>
    console.log('마운트됨')
)
onUpdated(()=>
    console.log('업데이트됨')
)

console.log('created');
</script>