<template>
    {{ state.nested.count }}{{ state.arr[0] }}
    <button @click="increse">증가</button>
</template>
<script setup>
import {reactive} from 'vue';
let state=reactive({
    nested:{count:0},
    arr:['foo','bar']}
)

const increse =()=>{state.nested.count++}

</script>